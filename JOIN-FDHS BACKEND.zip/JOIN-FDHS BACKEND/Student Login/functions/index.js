const {logger} = require("firebase-functions");
const {onRequest} = require("firebase-functions/v2/https");
const {initializeApp} = require("firebase-admin/app");
const {getFirestore} = require("firebase-admin/firestore");
const axios = require("axios");

const API_KEY = "AIzaSyD7rTiijhl5e77p1beZ_17yKnrUJ13tfiE";

const logInS = onRequest({
  region: "asia-south1",
  cors: true,
}, async (req, res) => {
  try {
    const {username, password} = req.body;
    logger.info(username);
    logger.info(password);
    if (!username || !password) {
      logger.error("Username and password are required." +
        "Your request failed. Please try again.");
      return res.status(401).json({
        message: "Username and password are required." +
          " Your request failed. Please try again.",
      });
    }

    const UniqueID = username;

    // Retrieve user email from the UniqueID
    const userEmailData = await retrieveUserEmail(UniqueID);
    if (!userEmailData) {
      logger.error("User not found. Please register first.");
      return res.status(404).json({
        message: "User not found. Please register first.",
      });
    }

    const usernames = userEmailData.email; // Set username to the retrieved.
    // Perform user sign-in
    const signInData = await signInUser(usernames, password);

    // Retrieve additional user data (if needed)
    const {data} = await retrieveUserData(usernames);

    // Capitalize the first letter of userType
    const userType = data.userType.
        charAt(0).toUpperCase() + data.userType.slice(1);

    // Prepare response object
    const response = {
      message: "Login successful",
      idToken: signInData.idToken,
      refreshToken: signInData.refreshToken,
      idTokenExpiresIn: signInData.idTokenExpiresIn,
      username: data.uniqueId,
      userType: userType,
      fullName: data.fullName,
    };
    // Send response
    res.status(200).json(response);
  } catch (error) {
    logger.error("Error signing in user:", error.message);
    if (error.message === "INVALID_LOGIN_CREDENTIALS") {
      // Send a 500 status code for invalid username or password
      res.status(212).json({
        message: "Invalid username or password",
      });
    } else {
      // For other errors, send a 500 status code with a generic error message
      res.status(501).json({
        message: "An error occurred while signing in. Please try again.",
      });
    }
  }
});

// Initialize Firebase Admin SDK
initializeApp();

// HTTP endpoint for handling user login
exports.LOGINSTUDENT = logInS;

/**
 * Sign in user using Firebase Authentication and retrieve additional user data.
 * @param {string} usernames - The user's email (username).
 * @param {string} password - The user's password.
 * @return {Promise<object>} - An object containing user data.
 * @throws {Error} - Throws an error if sign-in fails.
 */
async function signInUser(usernames, password) {
  try {
    const signInResponse = await axios.post(`https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${API_KEY}`, {
      email: usernames,
      password,
      returnSecureToken: true,
    });
    return signInResponse.data;
  } catch (error) {
    if (error.response && error.response.data && error.response.data.error) {
      const errorCode = error.response.data.error.code;
      if (errorCode === "INVALID_PASSWORD" || errorCode === "EMAIL_NOT_FOUND") {
        // Invalid credentials error
        throw new Error("Invalid username or password");
      } else {
        // Other errors
        throw new Error(error.response.data.error.message);
      }
    } else {
      throw new Error("An error occurred during sign-in");
    }
  }
}

/**
 * Retrieve user email from Firestore using UniqueID.
 * @param {string} UniqueID - The user's UniqueID.
 * @return {Promise<{email: string} | null>} - The user's email if found.
 */
async function retrieveUserEmail(UniqueID) {
  const userDoc = await getFirestore().
      collection("uniqueID").doc(UniqueID).get();
  if (userDoc.exists) {
    return {email: userDoc.data().email};
  }
  return null;
}

/**
 * Retrieve user data from multiple Firestore collections provided email.
 * @param {string} usernames - The user's email (username).
 * @return {Promise<{table: string, data: object} | null>}
 */
async function retrieveUserData(usernames) {
  const tables = ["student"]; // Add more collections if needed

  for (const table of tables) {
    const userDoc = await getFirestore().collection(table).doc(usernames).get();
    if (userDoc.exists) {
      return {table, data: userDoc.data()};
    }
  }

  return null;
}
