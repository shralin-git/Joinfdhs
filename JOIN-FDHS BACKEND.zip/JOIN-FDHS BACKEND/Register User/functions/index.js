const {logger} = require("firebase-functions");
const {https} = require("firebase-functions/v2");
const {initializeApp} = require("firebase-admin/app");
initializeApp();

const express = require("express");
const bodyParser = require("body-parser");
const admin = require("firebase-admin");
const nodemailer = require("nodemailer");

const app = express();

const auth = admin.auth();
const db = admin.firestore();

app.use(bodyParser.json());

const verifyToken = async (idToken) => {
  const decodedToken = await admin.auth().verifyIdToken(idToken);
  return decodedToken;
};

/**
 * Generates a password using the first 4 letters of the first name,
 * followed by '@' and a 3-digit random number.
 * @param {string} fullName The full name of the user.
 * @return {string} The generated password.
 */
function generatePassword(fullName) {
  const firstNamePart = fullName.substring(0, 3).toUpperCase();
  const randomPart = Math.floor(100 + Math.random() * 900);
  return `${firstNamePart}@${randomPart}`;
}

const sendMail = async (mailOptions) => {
  try {
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: "vinithnaik40@gmail.com",
        pass: "rdut jzcx wkdq jrkv",
      },
    });
    await transporter.sendMail(mailOptions);
  } catch (error) {
    logger.error("Error sending email:", error);
    throw error;
  }
};


const isValidEmail = (email) => {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(String(email).toLowerCase());
};

const getUniqueIdByUsername = async (username) => {
  const registrationRef = db.
      collection("registrationApplications").doc(username);
  const registrationDoc = await registrationRef.get();

  if (registrationDoc.exists) {
    const {uniqueId} = registrationDoc.data();
    return uniqueId || null;
  } else {
    throw new Error("User not found in registration applications.");
  }
};

const getfullNameOrInstitutionName = async (username) => {
  const registrationRef = db.
      collection("registrationApplications").doc(username);
  const registrationDoc = await registrationRef.get();

  if (registrationDoc.exists) {
    const {fullName} = registrationDoc.data();
    return fullName || "User";
  } else {
    throw new Error("User not found in registration applications.");
  }
};

const registerUser = async (decodedToken, username, status, res, remarks) => {
  const processedBy = decodedToken.email;

  const adminSnapshot = await db.collection("admin").doc(processedBy).get();
  const superAdminSnapshot = await db.
      collection("super admin").doc(processedBy).get();

  if (!adminSnapshot.exists && !superAdminSnapshot.exists) {
    return res.status(410).json({
      message:
        "Authorization failed: Only admins and super admins " +
        "are authorized to perform this action.",
    });
  }

  const registrationRef = db.
      collection("registrationApplications").doc(username);
  const registrationDoc = await registrationRef.get();

  if (!registrationDoc.exists) {
    return res.status(404).json({
      message: "User not found in registration applications."+
      " Please provide a valid username.",
    });
  }

  const {userType} = registrationDoc.data();
  const name = await getfullNameOrInstitutionName(username);
  const processedDate = new Date();
  const updateData = {status, processedBy, processedDate};

  if (remarks) {
    updateData.remarks = remarks;
  }

  await registrationRef.update(updateData);
  return {processedBy, userType, name, username};
};

const createUserInFirestore = async (username, userType, processedBy) => {
  const userDocRef = db.collection(userType).doc(username);
  await userDocRef.set({processedBy});

  if (userType === "mentor") {
    const registrationRef = db.
        collection("registrationApplications").doc(username);
    const registrationDoc = await registrationRef.get();

    if (registrationDoc.exists) {
      const userData = registrationDoc.data();
      await db.collection(userType).doc(username).set(userData);

      userData.isFirstTime = true;
      await userDocRef.set(userData);
    }
  }
};

const createUser = async (username, password) => {
  const userRecord = await auth.createUser({email: username, password});
  return userRecord;
};

const allowedOrigins = ["http://localhost:3000", "true"];

exports.registerUser = https.onRequest(
    {region: "asia-south1", cors: allowedOrigins},
    async (req, res) => {
      try {
        const idToken = req.headers.authorization;
        if (!idToken) {
          return res.status(401).json({
            message: "Authentication failed: No token"+
            " provided. Please try again.",
          });
        }

        const decodedToken = await verifyToken(idToken);
        if (!decodedToken) {
          return res.status(403).json({
            message: "Authentication failed: Invalid token."+
            " Please try again.",
          });
        }

        const {username, status, remarks = ""} = req.body;
        // Validate if username and password are provided
        if (!username || !status) {
          return res.status(400).json({error: "Username and "+
            "password are required."});
        }
        const {processedBy, userType, name} = await
        registerUser(decodedToken, username, status, res, remarks);

        if (status === "approve") {
          const userExists = await auth.
              getUserByEmail(username).catch((error) => {
                if (error.code !== "auth/user-not-found") {
                  throw error;
                }
              });

          if (!userExists) {
            const password = generatePassword(name);
            await createUser(username, password);

            await db.collection("Password").doc(username).set({password});


            if (!isValidEmail(username)) {
              return res.status(400).send({error: "Invalid email address"});
            }

            // Fetch the uniqueId by using the username
            const uniqueId = await getUniqueIdByUsername(username);

            const mailOptions = {
              from: `"JoinFDHS" <vinithnaik40@gmail.com>`,
              to: username,
              subject: "Congratulations! Your Application Has Been Approved",
              html: `
              <div style="font-family: Arial, sans-serif; max-width: 600px;
               margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0;
                border-radius: 10px; background-color: #f9f9f9;">
                <h2 style="color: #1a73e8; text-align: center; font-size:
                24px;">🎉 Congratulations! 🎉</h2>
                <p style="color: #333; font-size: 16px;">Dear
                 <strong>${name}</strong>,</p>
                <p style="color: #333; font-size: 16px;">We are delighted
                to inform you that your application has been approved.
                 Welcome to our community at <strong>
                 JoinFDHS</strong>!</p>

                <div style="padding: 10px 20px; background-color: #e0f3ff;
                 border-radius: 8px; margin-top: 20px;">
                  <p style="color: #333; font-size: 16px;"><strong>
                  Your account details:</strong></p>
                  <ul style="list-style: none; padding: 0;">
                    <li style="color: #333; font-size: 16px;"><strong>Username:
                    </strong> <span style="color: #1a73e8;">${uniqueId}</span>
                    </li>
                    <li style="color: #333; font-size: 16px;"><strong>Password:
                    </strong> <span style="color: #1a73e8;">${password}</span>
                    </li>
                  </ul>
                </div>

                ${remarks ? `<p style="color: #333; font-size: 16px; margin-top:
                   20px;"><strong>Remarks:</strong> <span
                   style="color: #1a73e8;">
                   ${remarks}</span></p>` : ""}

                <p style="color: #333; font-size: 16px; margin-top: 20px;">
                You can now log in using the above username and password.
                 Remember.</p>

                <div style="margin-top: 30px; border-top: 1px solid #e0e0e0;
                 padding-top: 10px; text-align: center;">
                  <p style="color: #333; font-size: 16px;">Best regards,</p>
                  <p style="color: #1a73e8; font-size: 18px; font-weight:
                  bold;">JoinFDHS</p>
                </div>
              </div>
              `,
            };


            await sendMail(mailOptions);
            await createUserInFirestore(username, userType, processedBy);

            return res.status(201).json({
              message: "Registration successful: An email containing"+
            " login credentials has been sent.",
            });
          } else {
            return res.status(409).json({
              message: "Registration failed: The user data has already been"+
            " updated, and the username is already registered.",
            });
          }
        } else if (status === "reject" || status === "hold") {
          const mailOptions = {
            from: `"JoinFDHS" <vinithnaik40@gmail.com>`,
            to: username,
            subject: "Application Status Update",
            html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px;
             margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0;
             border-radius: 10px; background-color: #f9f9f9;">
              <h2 style="color: #d32f2f; text-align: center; font-size:
               24px;">Application Status Update</h2>
              <p style="color: #333; font-size: 16px;">Dear
              <strong>${name}</strong>,</p>
              <p style="color: #333; font-size: 16px;">
                We regret to inform you that your application has been
                <span style="color: ${status === "reject" ? "#d32f2f" :
                   "#f57c00"};">
                  ${status === "reject" ? "rejected" : "put on hold"}.
                </span>
              </p>

              ${remarks ? `
              <div style="padding: 10px 20px; background-color: #ffebee;
               border-radius: 8px; margin-top: 20px;">
                <p style="color: #333; font-size: 16px;"><strong>Remarks:
                </strong></p>
                <p style="color: #d32f2f; font-size: 16px;">${remarks}</p>
              </div>` : ""}

              <p style="color: #333; font-size: 16px; margin-top: 20px;">
                If you have any questions, please contact the administrator at
                <a href="mailto:admin@fdhs.in" style="color:
                 #1a73e8; text-decoration: none;">
                  admin@fdhs.in
                </a> for further details.
              </p>

              <div style="margin-top: 30px; border-top: 1px solid #e0e0e0;
               padding-top: 10px; text-align: center;">
                <p style="color: #333; font-size: 16px;">Best regards,</p>
                <p style="color: #1a73e8; font-size: 18px; font-weight:
                 bold;">JoinFDHS</p>
              </div>

              <footer style="text-align: center; font-size: 12px; color:
               #888; margin-top: 20px;">
                <p>If you have any questions, feel free to contact us at
                 <a href="mailto:admin@fdhs.in" style="color:
                  #1a73e8; text-decoration: none;">admin@fdhs.in</a></p>
              </footer>
            </div>
            `,
          };


          await sendMail(mailOptions);

          return res.status(200).json({
            message: `Application ${
              status === "reject" ? "rejected" : "put on hold"
            }: An email notification has been sent to the user.`,
          });
        } else {
          return res.status(200).json({
            message: "Application not approved: User not registered.",
          });
        }
      } catch (error) {
        logger.error("Error registering user:", error);

        if (
          error.code === "auth/id-token-expired" ||
          error.code === "auth/id-token-revoked"
        ) {
          return res.status(401).json({
            message: "Authentication failed: Token expired."+
            " Please log in again.",
          });
        } else if (error.code === "auth/id-token-invalid") {
          return res.status(401).json({
            message: "Authentication failed: Invalid token."+
            " Please log in again.",
          });
        } else if (error.code === "auth/argument-error") {
          return res.status(400).json({
            message: "Request failed: Invalid token argument.",
          });
        }

        return res.status(500).json({
          message: "Internal Server Error: Something went wrong.",
        });
      }
    },
);
