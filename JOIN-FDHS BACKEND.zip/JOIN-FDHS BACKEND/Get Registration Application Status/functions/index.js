const {logger} = require("firebase-functions");
const {onRequest} = require("firebase-functions/v2/https");
const {initializeApp} = require("firebase-admin/app");
const {getFirestore} = require("firebase-admin/firestore");
const admin = require("firebase-admin");

initializeApp();

// const db = admin.firestore();
const firestore = admin.firestore();
/**
 * Verifies an authentication token.
 *
 * @param {string} idToken - The ID token to verify.
 * @return {Promise<object>} - Decoded token information.
 * @throws {Error} - If verification fails.
 */
async function verifyToken(idToken) {
  const decodedToken = await admin.auth().verifyIdToken(idToken);
  return decodedToken;
}

/**
 * Checks if a user is an admin or a super admin.
 *
 * @param {string} email - The email address of the user.
 * @return {Promise<boolean>}
 * @throws {Error} - If an error occurs during the process.
 */
async function isAdminUser(email) {
  const firestore = getFirestore();

  // Check if the user exists in the admin collection
  const adminDoc = await firestore.collection("admin").doc(email).get();
  if (adminDoc.exists) {
    return true; // User is an admin
  }

  // Check if the user exists in the superAdmin collection
  const superAdminDoc = await firestore.
      collection("super admin").doc(email).get();
  if (superAdminDoc.exists) {
    return true; // User is a super admin
  }

  return false; // User is neither admin nor super admin
}

const allowedOrigins = [
  "http://localhost:3000",
  "true",
];

// API endpoint to retrieve user information
exports.getRegistrationApplicationByStatus = onRequest({
  region: "asia-south1", cors: allowedOrigins,
}, async (req, res) => {
  try {
    const status = (req.query.status);
    // Extract the ID token from the request headers
    const idToken = req.headers.authorization;
    if (!idToken) {
      return res.status(400).send("ID token is missing");
    }

    let decodedToken;
    try {
      decodedToken = await verifyToken(idToken);
    } catch (error) {
      if (error.code === "auth/id-token-expired") {
        return res.status(401).send("ID token has expired");
      }
      return res.status(401).send("Invalid ID token");
    }
    if (!decodedToken) {
      return res.status(401).send("Invalid ID token");
    }

    // Extract user information from the token
    const adminEmail = decodedToken.email;
    const isAdmin = await isAdminUser(adminEmail);
    if (!isAdmin) {
      return res.status(403).send("You are not authorized" +
        " to view user information");
    }

    const userDetails = [];

    // Retrieve user details for registration applications
    const registrationSnapshot = await firestore
        .collection("registrationApplications")
        .where("status", "==", status)
        .get();
    registrationSnapshot.forEach((doc) => {
      userDetails.push({id: doc.id, data: doc.data()});
    });

    res.status(200).json({userDetails});
  } catch (error) {
    logger.error(error);
    res.status(500).json({message: "Internal Server Error"});
  }
});
