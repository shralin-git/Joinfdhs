const {logger} = require("firebase-functions");
const {onRequest} = require("firebase-functions/v2/https");
const admin = require("firebase-admin");
const credentials = require("./key.json");

// Initialize Firebase Admin SDK
admin.initializeApp({
  credential: admin.credential.cert(credentials),
});
const db = admin.firestore();

// HTTP endpoint for verifying OTP
const verifyOTP = onRequest({
  region: "asia-south1",
  cors: true,
}, async (req, res) => {
  try {
    const {otp} = req.body;

    // Check if OTP is provided
    if (!otp) {
      logger.error("OTP is required.");
      return res.status(400).json({
        message: "OTP is required to verify.",
      });
    }

    // Find the document with the matching OTP in the OTP collection
    const otpQuery = await db.
        collection("OTP").where("otp", "==", otp).get();

    if (otpQuery.empty) {
      logger.error("No email found for the provided OTP.");
      return res.status(404).json({
        message: "No email found for the provided OTP."+
        " Please request a new OTP.",
      });
    }

    // Assume only one OTP document matches (use first document found)
    const otpDoc = otpQuery.docs[0];
    const {email, createdAt} = otpDoc.data();

    // Check if the OTP has expired (2 minutes)
    const currentTime = new Date();
    const otpCreationTime = createdAt.toDate();
    const timeDifference = (currentTime - otpCreationTime) / 1000;

    if (timeDifference > 120) {
      logger.error("OTP has expired for this email.");

      await db.collection("OTP").doc(otpDoc.id).delete();

      return res.status(403).json({
        message: "OTP has expired. Please request a new OTP.",
      });
    }

    // OTP is valid, now retrieve all Token documents based on email
    const tokenDoc = await db.
        collection("Token").doc(email).get();

    if (tokenDoc.empty) {
      logger.error("No token data found for this email.");
      return res.status(404).json({
        message: "No token data found for this email.",
      });
    }

    const tokenData = tokenDoc.data();

    // OTP is valid
    logger.info(`OTP verification successful for email: ${email}`);
    await db.collection("Token").doc(email).delete();
    return res.status(200).json({
      message: "OTP verification successful.",
      tokenData: tokenData,
    });
  } catch (error) {
    logger.error("Error verifying OTP:", error.message);
    res.status(500).json({
      message: "An error occurred while verifying the"+
      " OTP. Please try again.",
    });
  }
});

// Export the verifyOTP function
exports.verifyOTP2 = verifyOTP;
