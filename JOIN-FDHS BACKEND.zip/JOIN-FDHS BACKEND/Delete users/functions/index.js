const {logger} = require("firebase-functions");
const {onRequest} = require("firebase-functions/v2/https");
const {initializeApp} = require("firebase-admin/app");
const admin = require("firebase-admin");
const nodemailer = require("nodemailer");

initializeApp();

const db = admin.firestore();

/**
 * Verifies an authentication token.
 *
 * @param {string} idToken - The ID token to verify.
 * @return {Promise<object>} - Decoded token information.
 * @throws {Error} - If verification fails.
 */
async function verifyToken(idToken) {
  const decodedToken = await admin.auth().verifyIdToken(idToken);
  return decodedToken.email;
}

/**
 * Validates an email address.
 * @param {string} email The email address to validate.
 * @return {boolean} `true` if the email is valid, otherwise `false`.
 */
function isValidEmail(email) {
  const re = /\S+@\S+\.\S+/;
  return re.test(email);
}

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "vinithnaik40@gmail.com",
    pass: "rdut jzcx wkdq jrkv",
  },
});

exports.DeleteUserByAdmins = onRequest(
    {
      region: "asia-south1",
      cors: ["http://localhost:3000", "true"],
    },
    async (req, res) => {
      try {
        const idToken = req.headers.authorization;
        if (!idToken) {
          return res.status(400).json({error: "ID token is missing"});
        }

        let adminEmail;
        try {
          adminEmail = await verifyToken(idToken);
        } catch (error) {
          if (error.code === "auth/id-token-expired") {
            return res.status(402).send("ID token has expired");
          }
          return res.status(401).send("Invalid ID token");
        }

        if (!adminEmail) {
          return res.status(401).send("Invalid ID token");
        }

        const adminDoc = await db.collection("admin").doc(adminEmail).get();
        if (!adminDoc.exists) {
          // Check the superAdmin collection
          const superAdminDoc = await db.
              collection("super admin").doc(adminEmail).get();
          if (!superAdminDoc.exists) {
            return res.status(403).json({error: "You are not authorized"});
          }
        }

        // Step 2: Get the email from the request body
        const {deleteEmail} = req.body;
        if (!deleteEmail || !isValidEmail(deleteEmail)) {
          return res.status(400).json({error: "Invalid email format"});
        }

        // Step 3: Check if the email exists in any of the collections
        const collections = ["student", "mentor", "admin",
          "registrationApplications", "OTP", "Password"];
        let userFound = false;

        for (const collection of collections) {
          const docRef = db.collection(collection).doc(deleteEmail);
          const docSnapshot = await docRef.get();

          if (docSnapshot.exists) {
            userFound = true;

            // Delete the document
            await docRef.delete();
            console.log(`Deleted ${collection} document`+
              ` for email: ${deleteEmail}`);
          }
        }

        // Step 4: Check and delete the user from Firebase Authentication
        let authUserFound = false;
        try {
          const userRecord = await admin.auth().getUserByEmail(deleteEmail);
          authUserFound = true;
          await admin.auth().deleteUser(userRecord.uid);
          console.log(`Deleted user from Firebase`+
            ` Authentication: ${deleteEmail}`);
        } catch (authError) {
          if (authError.code === "auth/user-not-found") {
            console.log(`User not found in Firebase`+
              ` Authentication: ${deleteEmail}`);
          } else {
            throw authError; // Re-throw unexpected errors
          }
        }

        if (!userFound && !authUserFound) {
          return res.status(404).
              json({message: "User already deleted in both"+
                " Authentication and Firestore"});
        }

        if (userFound) {
          const mailOptions = {
            from: `"JoinFDHS" <vinithnaik40@gmail.com>`,
            to: deleteEmail,
            subject: "Account Deletion Notification",
            html: `
              <div style="font-family: Arial, sans-serif;
               line-height: 1.6; margin:
              20px; padding: 20px; background-color: #f9f9f9; border-radius:
              8px; border: 1px solid #ddd;">
                <h2 style="color: #4A90E2;">Account Deletion Notification</h2>
                <p>Dear User,</p>
                <p style="font-size: 16px;">This is to inform
                 you that your account
                has been <strong>deleted by the admin</strong>.</p>
                <p>If you have any questions, please contact us immediately.</p>
                <p>Thank you for being a part of our community.</p>
                <p>Sincerely,</p>
                <p><strong>JoinFDHS</strong></p>
              </div>
            `,
          };

          await transporter.sendMail(mailOptions);
        }

        // Step 7: Respond to the client
        res.status(200).json({message: "User deleted successfully."});
      } catch (error) {
        logger.error("Error deleting user:", error);
        res.status(500).json({error: "Internal Server Error"});
      }
    },
);
