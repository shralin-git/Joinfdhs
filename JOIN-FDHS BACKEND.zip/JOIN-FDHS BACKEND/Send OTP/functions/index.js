const {logger} = require("firebase-functions");
const {onRequest} = require("firebase-functions/v2/https");
const {initializeApp} = require("firebase-admin/app");
const {getFirestore} = require("firebase-admin/firestore");
const nodemailer = require("nodemailer");

initializeApp();

const db = getFirestore();

// Nodemailer transporter setup
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "medikshastudent@gmail.com",
    pass: "yhfb vgzg ajgi yzug",
  },
});

/**
 * Generates a 6-digit OTP (One-Time Password).
 * @return {string} A 6-digit OTP as a string.
 */
function generateOTP() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

/**
 * Validates if the input is in an email format.
 * @param {string} input
 * @return {boolean} True if the input is
 */
function isValidEmail(input) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(input);
}

const sendOTP = onRequest(
    {
      region: "asia-south1",
      cors: true,
    },
    async (req, res) => {
      try {
        let {email} = req.body;

        if (!email) {
          logger.error("Email or Unique ID is required.");
          return res.status(400).json({
            message: "Email or Unique ID is required to send OTP.",
          });
        }

        // Check if the input is a valid email format
        if (!isValidEmail(email)) {
          const uniqueIdDoc = await db.collection("uniqueID").doc(email).get();

          if (!uniqueIdDoc.exists) {
            logger.error("Unique ID not found in the database.");
            return res.status(404).json({
              message: "Unique ID not found in the system.",
            });
          }

          // Retrieve email from the uniqueId document
          email = uniqueIdDoc.data().email;

          if (!email) {
            logger.error("Email not found for the provided Unique ID.");
            return res.status(404).json({
              message: "No email associated with the provided Unique ID.",
            });
          }
        }

        // Generate OTP
        const otp = generateOTP();

        // Store OTP in Firestore with email as the primary key
        await db.collection("OTP").doc(email).set({
          email: email,
          otp: otp,
          createdAt: new Date(),
        });

        // Mail content
        const mailOptionsUser = {
          from: `"Mediksha"`,
          to: email,
          subject: "Verify Your Email - Mediksha OTP Verification",
          html: `
          <div style="font-family: Arial, sans-serif; max-width:
          600px; margin: auto; padding: 20px; border:
          1px solid #e0e0e0; border-radius: 10px;">
            <h2 style="text-align: center; color: #2d88ff;
            ">Welcome to Mediksha!</h2>
            <p style="font-size: 16px; color: #333;">
              Dear User,
            </p>
            <p style="font-size: 16px; color: #333;">
              Thank you for registering with Mediksha. To complete
               the registration process and verify your email
               address, please use the following One-Time Password (OTP):
            </p>
            <div style="text-align: center; padding: 15px;
            background-color: #f4f4f4; border-radius: 5px; margin: 20px 0;">
              <span style="font-size: 24px; font-weight:
              bold; color: #2d88ff;">${otp}</span>
            </div>
            <p style="font-size: 16px; color: #333;">
              This OTP is valid for the next 10 minutes. If you
               did not request this verification, please
               disregard this email.
            </p>
            <p style="font-size: 16px; color: #333;">
              <b>What’s next?</b><br>
              Simply enter the above OTP in the verification field
               on the website or app to confirm your email address.
            </p>
            <p style="font-size: 16px; color: #333;">
              If you encounter any issues or need assistance,
              please don't hesitate to contact our support team
               at <a href="mailto:medikshastudent@gmail.com">
               medikshastudent@gmail.com</a>.
            </p>
            <p style="font-size: 16px; color: #333;">
              Thank you for choosing Mediksha!
            </p>
            <p style="font-size: 16px; color: #333;">
              Best regards,<br>
              <b>Mediksha Support Team</b>
            </p>
            <hr style="border: none; border-top:
            1px solid #e0e0e0; margin: 30px 0;">
            <p style="font-size: 12px; color: #999; text-align: center;">
              This is an automated email, please do not reply.
              If you have any questions, contact our support team.
            </p>
          </div>
        `,
        };

        // Send OTP email
        transporter.sendMail(mailOptionsUser, (error, info) => {
          if (error) {
            console.error("Error sending email to user:", error);
          } else {
            console.log("User email sent:", info.response);
          }
        });

        res.status(200).json({
          message: "OTP sent successfully to the provided email address.",
        });
      } catch (error) {
        logger.error("Error sending OTP:", error.message);
        res.status(500).json({
          message: "An error occurred while sending the OTP. Please try again.",
        });
      }
    },
);

exports.sendOTP = sendOTP;
