const {logger} = require("firebase-functions");
const {onRequest} = require("firebase-functions/v2/https");
const {initializeApp} = require("firebase-admin/app");
const admin = require("firebase-admin");
const nodemailer = require("nodemailer");

initializeApp();

const db = admin.firestore();

/**
 * Verifies an authentication token.
 *
 * @param {string} idToken - The ID token to verify.
 * @return {Promise<string>} - Decoded admin email.
 * @throws {Error} - If verification fails.
 */
async function verifyToken(idToken) {
  const decodedToken = await admin.auth().verifyIdToken(idToken);
  return decodedToken.email;
}

/**
 * Validates an email address.
 * @param {string} email The email address to validate.
 * @return {boolean} `true` if the email is valid, otherwise `false`.
 */
function isValidEmail(email) {
  const re = /\S+@\S+\.\S+/;
  return re.test(email);
}

/**
 * Validates a phone number.
 * @param {string} phoneNumber The phone number to validate.
 * @return {boolean} `true` if the phone number is valid, otherwise `false`.
 */
function isValidPhoneNumber(phoneNumber) {
  const re = /^\d{10}$/;
  return re.test(phoneNumber);
}

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "vinithnaik40@gmail.com",
    pass: "rdut jzcx wkdq jrkv",
  },
});

// API to update user profile (admin-verified)
exports.UpdateUserProfileByAdmin = onRequest(
    {
      region: "asia-south1",
      cors: ["http://localhost:3000", "true"],
    },
    async (req, res) => {
      try {
        const idToken = req.headers.authorization;
        if (!idToken) {
          return res.status(400).json({error: "ID token is missing"});
        }

        // Step 1: Verify admin token and check if email exists in admin table
        let adminEmail;
        try {
          adminEmail = await verifyToken(idToken);
        } catch (error) {
          if (error.code === "auth/id-token-expired") {
            return res.status(402).send("ID token has expired");
          }
          return res.status(401).send("Invalid ID token");
        }

        if (!adminEmail) {
          return res.status(401).send("Invalid ID token");
        }

        const adminDoc = await db.collection("admin").doc(adminEmail).get();
        if (!adminDoc.exists) {
        // Check the superAdmin collection
          const superAdminDoc = await db.
              collection("super admin").doc(adminEmail).get();
          if (!superAdminDoc.exists) {
            return res.status(403).json({error: "You are not authorized"});
          }
        }

        // Step 2: Get the username from request body
        let {username} = req.body;

        if (!username) {
          return res.status(400).json({error: "Username is required"});
        }

        let email;

        // Check if the username is a valid email
        if (isValidEmail(username)) {
          email = username;
          console.log(email);
        } else {
          try {
            const uniqueIdDoc = await db.
                collection("uniqueID").doc(username).get();

            if (!uniqueIdDoc.exists) {
              return res.status(404).json({error: "Unique ID not found"});
            }

            // Retrieve the email from the unique ID document
            username = uniqueIdDoc.data().email;

            if (!username) {
              return res.status(404).
                  json({error: "Email not associated with this unique ID"});
            }
          } catch (error) {
            console.error("Error fetching email from unique ID:", error);
            return res.status(500).
                json({error: "Internal server error while fetching email"});
          }
        }

        // Now, `email` can be used as the username
        console.log("Using email:", username);

        // Proceed with further logic using the `email` as the username
        let userType = null;
        let userDocRef = null;

        const collections = ["student", "mentor", "admin"];
        for (const collection of collections) {
          const docRef = db.collection(collection).doc(username);
          const docSnapshot = await docRef.get();
          if (docSnapshot.exists) {
            userType = collection; // Found which table the email belongs to
            userDocRef = docRef;
            break;
          }
        }

        if (!userType) {
          return res.status(404).json({error: "User not found"});
        }

        // Step 4: Based on userType, update the corresponding fields
        const {
          fullName,
          RollNumber,
          collegeName,
          stateOfResidence,
          specialization,
          mbbsNumber,
          collegeOrInstitution,
          phoneNumber,
          EmployeeID,
        } = req.body;

        // Validate phone number format if provided
        if (phoneNumber && !isValidPhoneNumber(phoneNumber)) {
          return res.status(400).json({error: "Invalid phone number format"});
        }

        // Update the data based on user type
        const updatedData = {};

        if (userType === "student") {
          if (fullName) updatedData.fullName = fullName;
          if (RollNumber) updatedData.RollNumber = RollNumber;
          if (collegeName) updatedData.collegeName = collegeName;
          if (stateOfResidence) {
            updatedData.stateOfResidence = stateOfResidence;
          }
          if (phoneNumber) updatedData.phoneNumber = phoneNumber;
          updatedData.lastUpdate = admin.firestore.FieldValue.serverTimestamp();
        } else if (userType === "mentor") {
          if (fullName) updatedData.fullName = fullName;
          if (phoneNumber) updatedData.phoneNumber = phoneNumber;
          if (specialization) updatedData.specialization = specialization;
          if (stateOfResidence) {
            updatedData.stateOfResidence = stateOfResidence;
          }
          if (mbbsNumber) updatedData.mbbsNumber = mbbsNumber;
          if (collegeOrInstitution) {
            updatedData.collegeOrInstitution = collegeOrInstitution;
          }
          updatedData.lastUpdate = admin.firestore.FieldValue.serverTimestamp();
        } else if (userType === "admin") {
          if (fullName) updatedData.fullName = fullName;
          if (phoneNumber) updatedData.phoneNumber = phoneNumber;
          if (stateOfResidence) {
            updatedData.stateOfResidence = stateOfResidence;
          }
          if (collegeOrInstitution) {
            updatedData.collegeOrInstitution = collegeOrInstitution;
          }
          if (EmployeeID) updatedData.EmployeeID = EmployeeID;
          updatedData.lastUpdate = admin.firestore.FieldValue.serverTimestamp();
        }

        // Step 5: Update Firestore with new data
        await userDocRef.update(updatedData);

        // Send confirmation email to the updated email address
        const mailOptions = {
          from: `"JoinFDHS" <vinithnaik40@gmail.com>`,
          to: username,
          subject: "Profile Update Notification from Admin",
          html: `
              <div style="font-family: Arial, sans-serif; line-height: 1.6;
              margin: 20px; padding: 20px; background-color: #f9f9f9;
              border-radius: 8px; border: 1px solid #ddd;">
              <h2 style="color: #4A90E2;">Profile Update Notification</h2>
              <p>Dear <strong>${fullName || "User"}</strong>,</p>
              <p style="font-size: 16px;">Your profile has been
              <strong>successfully updated by the Admin</strong>.</p>
              <p>Thank you for being a valued member of JoinFDHS.</p>
              <p>Sincerely,</p>
              <p><strong>JoinFDHS</strong></p>
            </div>
          `,
        };

        transporter.sendMail(mailOptions, (error, info) => {
          if (error) {
            console.error("Error sending email:", error);
          } else {
            console.log("Email sent:", info.response);
          }
        });

        res.status(200).
            json({message: "User information updated successfully."});
      } catch (error) {
        logger.error("Error updating user information:", error);
        res.status(500).json({error: "Internal Server Error"});
      }
    },
);
