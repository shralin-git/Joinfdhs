// The Cloud Functions for Firebase SDK to create Cloud Functions and triggers.
const {logger} = require("firebase-functions");
const {onRequest} = require("firebase-functions/v2/https");
const express = require("express");
const app = express();
const nodemailer = require("nodemailer");
const admin = require("firebase-admin");
const credentials = require("./key.json");

// Initialize Firebase Admin SDK
admin.initializeApp({
  credential: admin.credential.cert(credentials),
});
const db = admin.firestore();
const auth = admin.auth();

app.use(express.json());
app.use(express.urlencoded({extended: true}));

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "vinithnaik40@gmail.com",
    pass: "rdut jzcx wkdq jrkv",
  },
});

/**
 * Validates an email address.
 * @param {string} email The email address to validate.
 * @return {boolean} `true` if the email is valid, otherwise `false`.
 */
function validateEmail(email) {
  const re = /\S+@\S+\.\S+/;
  return re.test(email);
}

/**
 * Generates a unique ID by combining the first 4 letters of the full name,
 * a 2-digit random number, and ends with "fdhs".
 * @param {string} fullName The full name of the student.
 * @return {string} The generated unique ID.
 */
function generateUniqueId(fullName) {
  // Extract the first 4 letters from the fullName and convert to uppercase
  const namePart = fullName.substring(0, 3).toUpperCase();

  // Generate a random 4-digit number (from 1000 to 9999)
  const randomPart = Math.floor(1000 + Math.random() * 9000);

  const studentNumber = `${namePart}${randomPart}@FDHS`;
  // Return the ID in the required format
  return studentNumber;
}

/**
 * Generates a password using the first 4 letters of the first name,
 * followed by '@' and a 3-digit random number.
 * @param {string} fullName The full name of the user.
 * @return {string} The generated password.
 */
function generatePassword(fullName) {
  // Extract the first 4 letters from the fullName and convert to uppercase
  const firstNamePart = fullName.substring(0, 3).toUpperCase();

  // Generate a random 3-digit number (from 100 to 999)
  const randomPart = Math.floor(100 + Math.random() * 900);

  // Return the password in the required format
  return `${firstNamePart}@${randomPart}`;
}

/**
 * Validates a phone number.
 * @param {string} phoneNumber The phone number to validate.
 * @return {boolean} `true` if the phone number is valid, otherwise `false`.
 */
function validatePhoneNumber(phoneNumber) {
  const re = /^\d{10}$/;
  return re.test(phoneNumber);
}

/**
     * Generates a random character from the given set of characters.
     *
     * @return {string} A random character.
     */
function getRandomCharacter() {
  const characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabc"+
  "defghijklmnopqrstuvwxyz0123456789";
  return characters.charAt(Math.floor(Math.random() * characters.length));
}

/**
 * Generates a string that starts with a letter.
 *
 * @return {string} - The generated string.
 */
function generateCustomString() {
  const numbers = Math.floor(Math.random() * 90000) + 10000;
  return `${numbers}`;
}

// HTTP endpoint for adding a new user registration with OTP verification
exports.StudentRegistration = onRequest({
  region: "asia-south1",
  cors: true,
}, async (req, res) => {
  try {
    const userData = req.body;
    const {email, fullName, RollNumber,
      collegeName, stateOfResidence,
      phoneNumber} = userData;

    // Validate email format
    if (!validateEmail(email)) {
      return res.status(401).json({message: "Invalid email format."+
        " Your request failed. Please try again"});
    }

    // Validate phone number format
    if (!validatePhoneNumber(phoneNumber)) {
      return res.status(402).json({message: "Invalid phone number format"+
        " Your request failed. Please try again"});
    }

    try {
      const collectionsToCheck = ["student", "mentor", "admin", "super admin"];
      for (const collection of collectionsToCheck) {
        const userSnapshot = await db.collection(collection).doc(email).get();
        if (userSnapshot.exists) {
          return res.status(404).json({
            message: `User already exists in this application`,
          });
        }
      }
    } catch (error) {
      console.error("Error checking for existing user:", error);
      return res.status(500).json({
        message: "Error checking for existing user",
      });
    }

    // Ensure all required fields are provided
    const requiredFields = ["fullName", "email",
      "RollNumber", "collegeName",
      "stateOfResidence", "phoneNumber"];
    const missingFields = requiredFields.filter((field) => !userData[field]);

    if (missingFields.length > 0) {
      return res.status(405).json({message: `Missing required fields:`+
        ` ${missingFields.join(", ")}. Your request failed. Please try again`});
    }

    // Generate a unique ID for the student
    let uniqueId = generateUniqueId(fullName);
    console.log("First unique ID " + uniqueId);

    // Generate a password for the user
    const password = generatePassword(fullName);

    // Check if uniqueId exists in the Firestore collection
    const uniqueIdDoc = await db.collection("uniqueID").doc(uniqueId).get();

    if (uniqueIdDoc.exists) {
      console.log("The uniqueId exists in the database.");
      // Extract the first 4 letters from the fullName and convert to uppercase
      const namePart = fullName.substring(0, 3).toUpperCase();

      const customString = generateCustomString();

      const studentNumber = `${namePart}${customString}@FDHS`;

      const randomChar = getRandomCharacter();

      const updatedUniqueId = studentNumber.slice(0, 3) +
      randomChar + studentNumber.slice(3);

      uniqueId = updatedUniqueId;

      console.log("Changed unique ID "+ updatedUniqueId);
    } else {
      console.log("The uniqueId does not exist in the database.");
    }

    // Store registration details in Firestore under the "student" collection
    const userInfo = {
      uniqueId,
      fullName,
      email,
      RollNumber,
      collegeName,
      stateOfResidence,
      phoneNumber,
      submitDate: new Date(),
      userType: "student",
      isFirstTime: "true",
    };

    // Store the user data in Firestore
    await db.collection("student").doc(email).set(userInfo);

    // Store the uniqueId and email in the "uniqueID" collection
    await db.collection("uniqueID").doc(uniqueId).set({email});

    // Create user in Firebase Authentication
    await auth.createUser({email, password});

    // Send email to the user with the provided password
    const mailOptionsUser = {
      from: `"JoinFDHS" <vinithnaik40@gmail.com>`,
      to: email,
      subject: "Welcome to JoinFDHS!",
      html: `
        <div style="font-family: Arial, sans-serif; color: #333;
        padding: 20px; background-color: #f9f9f9;">
          <div style="max-width: 600px; margin: 0 auto; background-color:
          white; padding: 20px; border-radius: 10px; box-shadow: 0 4px 8px
          rgba(0, 0, 0, 0.1);">
            <h2 style="color: #007BFF; text-align: center;">
            Welcome to JoinFDHS!</h2>
            <p>Dear <strong>${fullName}</strong>,</p>
            <p style="font-size: 16px; line-height: 1.6;">
              We are delighted to welcome you to our community! You can
              now access our platform.
            </p>

            <div style="padding: 10px; background-color:
            #f1f1f1; border-radius: 5px;">
              <p style="margin: 0;"><strong>Username:</strong> ${uniqueId}</p>
              <p style="margin: 0;"><strong>Password:</strong> ${password}</p>
            </div>

            <p style="font-size: 16px; line-height: 1.6; margin-top: 20px;">
              <strong>You can now log in using the above credentials.</strong>
            </p>

            <a href="" style="display:
            inline-block; margin-top: 20px; background-color:
            #007BFF; color: white;
            text-decoration: none; padding: 10px 20px;
            border-radius: 5px; font-size: 16px;">
              Log in to Your Account
            </a>

            <p style="font-size: 16px; line-height: 1.6; margin-top: 20px;">
              If you have any questions or need assistance,
              feel free to <a href="#"
              style="color: #007BFF; text-decoration:
                none;">contact our support team</a>.
            </p>

            <p style="font-size: 16px; margin-top: 20px;">Best regards,<br>
            <strong>JoinFDHS</strong></p>

            <hr style="border: none; border-top:
            1px solid #ddd; margin: 20px 0;">
            <p style="font-size: 12px; color: #777; text-align: center;">
            <br>
            </p>
          </div>
        </div>
      `,
    };
    transporter.sendMail(mailOptionsUser, (error, info) => {
      if (error) {
        console.error("Error sending email to user:", error);
      } else {
        console.log("User email sent:", info.response);
      }
    });

    // Send email to the sales team with student registration details
    const mailOptionsSales = {
      from: `"JoinFDHS" <vinithnaik40@gmail.com>`,
      to: "vinithnaik40@gmail.com",
      subject: "🎓 New Student Registration Details",
      html: `
    <div style="font-family: 'Helvetica Neue', Arial, sans-serif;
     background-color: #f4f4f4; padding: 20px;">
      <div style="max-width: 600px; margin: 0 auto; background-color:
       #ffffff; border-radius: 10px; overflow: hidden; box-shadow:
        0 4px 6px rgba(0, 0, 0, 0.1);">

        <!-- Header Section -->
        <div style="background-color: #2196F3; padding: 20px;
         text-align: center; color: #ffffff;">
          <h1 style="font-size: 24px; margin: 0;">
          New Student Registration</h1>
        </div>

        <!-- Body Section -->
        <div style="padding: 30px; color: #333; line-height: 1.6;">
          <p style="font-size: 18px; color: #2196F3;">
            <strong>Dear Sales Team,</strong>
          </p>

          <p style="font-size: 16px;">
            A new student has registered with the following details:
          </p>

          <table style="width: 100%; font-size: 16px;
           border-collapse: collapse; margin: 20px 0;">
            <tr>
              <td style="padding: 10px; background-color:
              #f9f9f9;"><strong>Name:</strong></td>
              <td style="padding: 10px;">${fullName}</td>
            </tr>
            <tr>
              <td style="padding: 10px; background-color:
              #f9f9f9;"><strong>Email:</strong></td>
              <td style="padding: 10px;">${email}</td>
            </tr>
            <tr>
              <td style="padding: 10px; background-color:
               #f9f9f9;"><strong>Phone Number:</strong></td>
              <td style="padding: 10px;">${phoneNumber}</td>
            </tr>
            <tr>
              <td style="padding: 10px; background-color:
              #f9f9f9;"><strong>RollNumber:</strong></td>
              <td style="padding: 10px;">${RollNumber}</td>
            </tr>
            <tr>
              <td style="padding: 10px; background-color:
              #f9f9f9;"><strong>College Name:</strong></td>
              <td style="padding: 10px;">${collegeName}</td>
            </tr>
            <tr>
              <td style="padding: 10px; background-color:
               #f9f9f9;"><strong>State of Permanent Residence:</strong></td>
              <td style="padding: 10px;">${stateOfResidence}</td>
            </tr>
          </table>

          <p style="font-size: 16px;">
            Best regards,<br>
            <strong style="color: #2196F3;">JoinFDHS</strong>
          </p>
        </div>

        <!-- Footer Section -->
        <div style="background-color: #f4f4f4; text-align:
         center; padding: 20px;">
          <p style="font-size: 14px; color: #777; margin: 0;">
            <strong>JoinFDHS</strong>
          </p>
        </div>
      </div>
    </div>
  `,
    };


    transporter.sendMail(mailOptionsSales, (error, info) => {
      if (error) {
        console.error("Error sending email to sales team:", error);
      } else {
        console.log("Sales team email sent:", info.response);
      }
    });

    // Send success response
    res.status(201).json({
      message: "Your application was successfully submitted!"+
      " Check your email for login credentials.",
    });
  } catch (error) {
    // Log error
    logger.error(`Error submitting registration application: ${error}`);

    // Handle errors
    res.status(500).json({message: "Internal Server Error"});
  }
});
