// The Cloud Functions for Firebase SDK to create Cloud Functions and triggers.
const {logger} = require("firebase-functions");
const {onRequest} = require("firebase-functions/v2/https");
const express = require("express");
const app = express();
const nodemailer = require("nodemailer");
const admin = require("firebase-admin");
const credentials = require("./key.json");
const {getFirestore} = require("firebase-admin/firestore");
// const cors = require("cors");
// Initialize Firebase Admin SDK
admin.initializeApp({
  credential: admin.credential.cert(credentials),
});
const db = admin.firestore();
const auth = admin.auth();

app.use(express.json());
app.use(express.urlencoded({extended: true}));


/**
 * Verifies an authentication token.
 *
 * @param {string} idToken - The ID token to verify.
 * @return {Promise<object>} - Decoded token information.
 * @throws {Error} - If verification fails.
 */
async function verifyToken(idToken) {
  const decodedToken = await admin.auth().verifyIdToken(idToken);
  return decodedToken;
}

/**
 * Checks if a user is an admin or super admin.
 *
 * @param {string} email - The email address of the user.
 * @return {Promise<{isAdmin: boolean, isSuperAdmin: boolean}>}
 * @throws {Error} - If an error occurs during the process.
 */
async function isAdminUser(email) {
  const firestore = getFirestore();

  // Check if the user is an admin
  const adminDoc = await firestore.collection("admin").doc(email).get();
  const isAdmin = adminDoc.exists;

  // Check if the user is a super admin
  const superAdminDoc = await firestore.
      collection("super admin").doc(email).get();
  const isSuperAdmin = superAdminDoc.exists;

  return {
    isAdmin,
    isSuperAdmin,
  };
}

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "vinithnaik40@gmail.com",
    pass: "rdut jzcx wkdq jrkv",
  },
});

/**
 * Validates an email address.
 * @param {string} email The email address to validate.
 * @return {boolean} `true` if the email is valid, otherwise `false`.
 */
function validateEmail(email) {
  const re = /\S+@\S+\.\S+/;
  return re.test(email);
}

/**
 * Validates a phone number.
 * @param {string} phoneNumber The phone number to validate.
 * @return {boolean} `true` if the phone number is valid, otherwise `false`.
 */
function validatePhoneNumber(phoneNumber) {
  const re = /^\d{10}$/;
  return re.test(phoneNumber);
}

/**
 * Generates a unique ID by combining the first 4 letters of the full name,
 * a 2-digit random number, and ends with "fdhs".
 * @param {string} fullName The full name of the student.
 * @return {string} The generated unique ID.
 */
function generateUniqueId(fullName) {
  // Extract the first 4 letters from the fullName and convert to uppercase
  const namePart = fullName.substring(0, 3).toUpperCase();

  // Generate a random 4-digit number (from 1000 to 9999)
  const randomPart = Math.floor(1000 + Math.random() * 9000);

  const studentNumber = `${namePart}${randomPart}@FDHS`;
  // Return the ID in the required format
  return studentNumber;
}

/**
 * Generates a password using the first 4 letters of the first name,
 * followed by '@' and a 3-digit random number.
 * @param {string} fullName The full name of the user.
 * @return {string} The generated password.
 */
function generatePassword(fullName) {
  // Extract the first 4 letters from the fullName and convert to uppercase
  const firstNamePart = fullName.substring(0, 3).toUpperCase();

  // Generate a random 3-digit number (from 100 to 999)
  const randomPart = Math.floor(100 + Math.random() * 900);

  // Return the password in the required format
  return `${firstNamePart}@${randomPart}`;
}

const createUser = async (email, password) => {
  {
    const userRecord = await auth.createUser({email: email, password});
    return userRecord;
  }
};

/**
     * Generates a random character from the given set of characters.
     *
     * @return {string} A random character.
     */
function getRandomCharacter() {
  const characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabc"+
  "defghijklmnopqrstuvwxyz0123456789";
  return characters.charAt(Math.floor(Math.random() * characters.length));
}

/**
 * Generates a string that starts with a letter.
 *
 * @return {string} - The generated string.
 */
function generateCustomString() {
  const numbers = Math.floor(Math.random() * 90000) + 10000;
  return `${numbers}`;
}


const allowedOrigins = [
  "http://localhost:3000",
  "true",
];

// HTTP endpoint for adding a new user registration
exports.AddUsersByAdmins = onRequest({
  region: "asia-south1", cors: allowedOrigins,
}, async (req, res) => {
  try {
    // Extract the ID token from the request headers
    const idToken = req.headers.authorization;
    if (!idToken) {
      return res.status(400).send("ID token is missing");
    }

    // Verify the ID token
    let decodedToken;
    try {
      decodedToken = await verifyToken(idToken);
    } catch (error) {
      if (error.code === "auth/id-token-expired") {
        return res.status(402).send("ID token has expired");
      }
      return res.status(401).send("Invalid ID token");
    }

    if (!decodedToken) {
      return res.status(401).send("Invalid ID token");
    }

    // Extract user information from the token
    const adminEmail = decodedToken.email;
    const isAdmin = await isAdminUser(adminEmail);
    if (!isAdmin) {
      return res.status(403).send("You are not authorized" +
        " to view user information");
    }
    const {userType, ...userData} = req.body;
    const {email, phoneNumber, fullName} = userData;

    // Validate email format and phone number length
    if (!validateEmail(email)) {
      return res.status(400).json({
        message: "Invalid email format. Your request failed. Please try again",
      });
    }

    if (!validatePhoneNumber(phoneNumber)) {
      return res.status(400).json({
        message:
          "Invalid phone number format. Phone number must "+
          "be 10 digits. Your request failed. Please try again",
      });
    }

    const currentDate = new Date();
    try {
      // Check if the user exists in the 'mentor' table
      const mentorSnapshot = await db.collection("mentor")
          .where("email", "==", email)
          .get();
      // Check if the user exists in the 'mentor' table
      const studentSnapshot = await db.collection("student")
          .where("email", "==", email)
          .get();

      // Check if the user exists in the 'admin' table
      const adminSnapshot = await db.collection("admin")
          .where("email", "==", email)
          .get();

      // If the user exists in either 'mentors' or 'admin', return an error
      if (!mentorSnapshot.empty || !adminSnapshot.empty ||
          !studentSnapshot.empty) {
        return res.status(400).json({
          message: "User already exists for this"+
          " application.",
        });
      }

      // Continue with registration process if user doesn't exist
    } catch (error) {
      console.error("Error checking for existing user:", error);
      return res.status(500).json({
        message: "Error checking for existing user in mentor or admin table",
      });
    }

    userData.processedBy = adminEmail;
    userData.processedDate = currentDate;
    userData.submitDate = currentDate;
    userData.isFirstTime = true;

    let requiredFields = [];
    let userInfo = {};
    let uniqueId = "";

    switch (userType) {
      case "student": {
        requiredFields = [
          "fullName",
          "email",
          "RollNumber",
          "collegeName",
          "stateOfResidence",
          "phoneNumber",
        ];
        uniqueId = generateUniqueId(fullName);

        // Check if uniqueId exists in the Firestore collection
        const uniqueIdDoc = await db.collection("uniqueID").doc(uniqueId).get();

        if (uniqueIdDoc.exists) {
          console.log("The uniqueId exists in the database.");

          const namePart = fullName.substring(0, 3).toUpperCase();
          const customString = generateCustomString();
          const studentNumber = `${namePart}${customString}@FDHS`;
          const randomChar = getRandomCharacter();
          const updatedUniqueId = studentNumber.slice(0, 3) +
          randomChar + studentNumber.slice(3);

          uniqueId = updatedUniqueId;

          console.log("Changed unique ID " + updatedUniqueId);
        } else {
          console.log("The uniqueId does not exist in the database.");
        }
      }
        userInfo = {
          uniqueId,
          userType: "student",
          email: userData.email,
          fullName: userData.fullName,
          RollNumber: userData.RollNumber,
          collegeName: userData.collegeName,
          stateOfResidence: userData.stateOfResidence,
          phoneNumber: userData.phoneNumber,
          ...userData,
        };
        break;

      case "mentor": {
        requiredFields = [
          "email",
          "phoneNumber",
          "fullName",
          "stateOfResidence",
          "mbbsNumber",
          "collegeOrInstitution",
          "specialization",
        ];
        uniqueId = generateUniqueId(fullName);

        // Check if uniqueId exists in the Firestore collection
        const uniqueIdDoc = await db.collection("uniqueID").doc(uniqueId).get();

        if (uniqueIdDoc.exists) {
          console.log("The uniqueId exists in the database.");

          const namePart = fullName.substring(0, 3).toUpperCase();
          const customString = generateCustomString();
          const studentNumber = `${namePart}${customString}@FDHS`;
          const randomChar = getRandomCharacter();
          const updatedUniqueId =
            studentNumber.slice(0, 3) + randomChar + studentNumber.slice(3);

          uniqueId = updatedUniqueId;

          console.log("Changed unique ID " + updatedUniqueId);
        } else {
          console.log("The uniqueId does not exist in the database.");
        }

        userInfo = {
          uniqueId,
          userType: "mentor",
          email: userData.email,
          phoneNumber: userData.phoneNumber,
          fullName: userData.fullName,
          stateOfResidence: userData.stateOfResidence,
          mbbsNumber: userData.mbbsNumber,
          collegeOrInstitution: userData.collegeOrInstitution,
          specialization: userData.specialization,
          ...userData,
        };
        break;
      }

      case "admin":
        requiredFields = ["email", "fullName", "phoneNumber",
          "collegeOrInstitution", "EmployeeID", "stateOfResidence"];
        userInfo = {
          userType: "admin",
          email: userData.email,
          fullName: userData.fullName,
          phoneNumber: userData.phoneNumber,
          collegeOrInstitution: userData.collegeOrInstitution,
          EmployeeID: userData.EmployeeID,
          stateOfResidence: userData.stateOfResidence,
          ...userData,
        };
        break;

      default:
        return res.status(400).json({message: "Invalid user type"});
    }


    const missingFields = requiredFields.filter(
        (field) => !Object.prototype.hasOwnProperty.call(userData, field),
    );

    if (missingFields.length > 0) {
      return res.status(400).json({
        message: `Missing required fields for ${userType}: ${missingFields.join(
            ", ",
        )}. Your request failed. Please try again`,
      });
    }

    // Store registration details in Firestore
    await db.collection(userType).doc(email).set(userInfo);

    // Store uniqueId in the 'uniqueID' collection
    if (userType === "student" || userType === "mentor") {
      await db.collection("uniqueID").doc(uniqueId).set({
        email: userData.email,
        uniqueId,
      });
    }

    // Log success
    logger.info(`${userType} registration application submitted successfully`);

    // Send success response
    res.status(201).json({
      message: `${userType} registration application submitted successfully`,
    });


    const recipientName = userData.fullName || "User";
    // Send email to the user
    const password = generatePassword(fullName);
    await createUser(email, password);

    let username = email; // Default username is email for admin
    if (userType === "student" || userType === "mentor") {
      username = uniqueId; // Username for student/mentor is uniqueId
    }


    const mailOptions = {
      from: `"JoinFDHS" <vinithnaik40@gmail.com>`,
      to: email,
      subject: "Welcome to JoinFDHS!",
      html: `
        <div style="font-family: Times New Roman, serif; color: #333;
        padding: 20px; background-color: #f9f9f9;">
          <div style="max-width: 600px; margin: 0 auto; background-color:
          white; padding: 20px; border-radius: 10px; box-shadow: 0 4px
          8px rgba(0, 0, 0, 0.1);">
            <h2 style="color: #007BFF; text-align: center; font-family:
            Times New Roman, serif;">Welcome to JoinFDHS!</h2>
            <p style="font-size: 16px; line-height: 1.6;">
              Dear <strong>${recipientName}</strong>,
            </p>
            <p style="font-size: 16px; line-height: 1.6;">
              We are delighted to welcome you to our community! You can
              now access our platform and explore a range of exciting offers.
            </p>

            <div style="padding: 15px; border: 1px solid #007BFF; border-
            radius: 5px; background-color: #f4f4f4;">
              <p style="margin: 0; font-size: 16px; line-height: 1.6;">
              <strong>Username:</strong> ${username}</p>
              <p style="margin: 0; font-size: 16px; line-height: 1.6;">
              <strong>Password:</strong> ${password}</p>
            </div>

            <p style="font-size: 16px; line-height: 1.6; margin-top: 20px;">
              You can now log in using the above credentials. Don't forget to
              <a href="#" style="color: #007BFF; text-decoration: underline;">
              reset your password</a> after logging in to ensure your
               account's security.
            </p>

            <a href="#" style="display: inline-block; margin-top: 20px;
            background-color: #007BFF; color: white; text-decoration:
            none; padding: 10px 20px; border-radius: 5px; font-size: 16px;">
              Log in to Your Account
            </a>

            <p style="font-size: 16px; line-height: 1.6; margin-top: 20px;">
              If you have any questions or need assistance, feel free to
              <a href="#" style="color: #007BFF; text-decoration:
              underline;">contact our support team</a>.
            </p>

            <p style="font-size: 16px; line-height: 1.6; margin-top: 20px;">
              Best regards,<br>
              <strong>JoinFDHS</strong>
            </p>
          </div>
        </div>
      `,
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.error("Error sending email:", error);
      } else {
        console.log("Email sent:", info.response);
      }
    });
  } catch (error) {
    // Log error
    logger.error(`Error submitting registration application: ${error}`);

    // Handle errors
    res.status(500).json({message: "Internal Server Error"});
  }
});
