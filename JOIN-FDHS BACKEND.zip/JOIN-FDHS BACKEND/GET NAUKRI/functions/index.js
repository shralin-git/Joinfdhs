const {logger} = require("firebase-functions");
const {onRequest} = require("firebase-functions/v2/https");
const {Storage} = require("@google-cloud/storage");
const {initializeApp} = require("firebase-admin/app");
const admin = require("firebase-admin");
const {getFirestore} = require("firebase-admin/firestore");

initializeApp();

const storage = new Storage();
const bucket = storage.bucket("gs://joinfdhs");

/**
 * Verifies an authentication token.
 *
 * @param {string} idToken - The ID token to verify.
 * @return {Promise<object>} - Decoded token information.
 * @throws {Error} - If verification fails.
 */
async function verifyToken(idToken) {
  const decodedToken = await admin.auth().verifyIdToken(idToken);
  return decodedToken;
}

/**
 * Checks if a user is authorized (admin, super admin, or donor).
 *
 * @param {string} email - The email address of the user.
 * @return {Promise<boolean>} - Returns true if authorized, false otherwise.
 */
async function isAuthorizedUser(email) {
  const firestore = getFirestore();

  // Check in "admin", "super admin", and "donor" collections
  const adminDoc = await firestore.collection("admin").doc(email).get();
  const studentDoc = await firestore.collection("super admin").doc(email).get();
  const donorDoc = await firestore.collection("donor").doc(email).get();

  return adminDoc.exists || studentDoc.exists || donorDoc.exists;
}

/**
 * Generates signed URLs for all files belonging to a specific email.
 *
 * @param {string} email - The email used as the path prefix in the bucket.
 * @param {number} expirationSeconds - The expiration time for the signed URL.
 * @return {Promise<Array<object>>} - List of files with their URLs.
 */
async function getFilesByEmail(email, expirationSeconds) {
  try {
    const [files] = await bucket.getFiles({prefix: `${email}/`});
    if (files.length === 0) {
      throw new Error("No files found for the given email");
    }

    const documents = files.filter((file) =>
      file.name !== `${email}/` && !file.name.endsWith("/"));

    const fileUrls = await Promise.all(
        documents.map(async (file) => {
          const [url] = await file.getSignedUrl({
            action: "read",
            expires: Date.now() + expirationSeconds * 1000,
          });
          return {filename: file.name, url};
        }),
    );

    return fileUrls;
  } catch (error) {
    logger.error("Error retrieving files by email:", error);
    throw error;
  }
}

/**
 * Retrieves specific fields from a Firestore collection.
 *
 * @param {string} collectionName - The name of the Firestore collection.
 * @param {Array<string>} skillsToMatch - The list of skills to search for.
 * @param {number} minYearsOfExperience - Minimum years of experience.
 * @return {Promise<Array<object>>} - A list of candidate data with file URLs.
 */
async function getUsersBySkills(collectionName,
    skillsToMatch, minYearsOfExperience) {
  const firestore = getFirestore();
  const collectionRef = firestore.collection(collectionName);
  const snapshot = await collectionRef
      .select(
          "Skills",
          "Email ID",
          "Years of Experience",
          "Candidate Name",
          "Phone Number",
          "Date of Updated Profile",
          "Current Location",
          "Preferred Location",
          "Current CTC",
          "Expected CTC",
          "Present Organization",
      )
      .get();

  if (snapshot.empty) {
    throw new Error("No documents found in the given collection.");
  }

  const allData = [];

  for (const doc of snapshot.docs) {
    const data = doc.data();
    const userSkills = data.Skills.split(",").map((skill) => skill.trim());
    const email = data["Email ID"];
    const yearsOfExperience = data["Years of Experience"];

    // Skip candidates with insufficient experience
    if (yearsOfExperience < minYearsOfExperience) continue;

    // Find the matching skills
    const matchedSkills = skillsToMatch.
        filter((skill) => userSkills.includes(skill.trim()));
    const numberOfMatchedSkills = matchedSkills.length;

    // Skip candidates with no matching skills
    if (numberOfMatchedSkills === 0) continue;

    const totalSkills = userSkills.length;
    const matchPercentage =
       totalSkills > 0 ? (numberOfMatchedSkills / totalSkills) * 100 : 0;

    // Get file URLs for the candidate
    let fileUrls = [];
    try {
      fileUrls = await getFilesByEmail(email, 600); // 10 minutes expiration
    } catch (error) {
      if (error.message !== "No files found for the given email") {
        throw error;
      }
    }

    allData.push({
      skills: userSkills,
      email,
      matchedSkills,
      yearsOfExperience,
      percentage: matchPercentage.toFixed(2),
      numberOfMatchedSkills,
      totalSkills,
      CandidateName: data["Candidate Name"],
      PhoneNumber: data["Phone Number"],
      DateofUpdatedProfile: data["Date of Updated Profile"],
      CurrentLocation: data["Current Location"],
      PreferredLocation: data["Preferred Location"],
      PresentOrganization: data["Present Organization"],
      CurrentCTC: data["Current CTC"],
      ExpectedCTC: data["Expected CTC"],
      fileUrls,
    });
  }

  // Sort by match percentage in descending order
  allData.sort((a, b) => b.percentage - a.percentage);

  return allData;
}

exports.getUsersBySkillsAPI = onRequest(
    {
      region: "asia-south1",
      cors: true,
    },
    async (req, res) => {
      try {
        const idToken = req.headers.authorization;
        if (!idToken) {
          return res.status(400).send("ID token is missing");
        }

        let decodedToken;
        try {
          decodedToken = await verifyToken(idToken);
        } catch (error) {
          if (error.code === "auth/id-token-expired") {
            return res.status(401).send("ID token has expired");
          }
          return res.status(401).send("Invalid ID token");
        }

        const adminEmail = decodedToken.email;
        const isAdmin = await isAuthorizedUser(adminEmail);
        if (!isAdmin) {
          return res.status(403).
              send("You are not authorized to access this resource");
        }

        const {collectionName, skills, minYearsOfExperience} = req.query;
        if (!collectionName || !skills || !minYearsOfExperience) {
          return res.status(400).json({
            error: "Collection name, skills, and minimum"+
            " years of experience are required.",
          });
        }

        const minYears = parseInt(minYearsOfExperience, 10);
        if (isNaN(minYears)) {
          return res.status(400).json({
            error: "Minimum years of experience must be a valid number.",
          });
        }

        const skillsArray = skills.split(",").map((skill) => skill.trim());

        const users = await getUsersBySkills(collectionName,
            skillsArray, minYears);
        res.status(200).json({users});
      } catch (error) {
        logger.error("Error processing request:", error);
        res.status(500).json({error: "Internal Server Error"});
      }
    },
);
