// The Cloud Functions for Firebase SDK to create Cloud Functions and triggers.
const {logger} = require("firebase-functions");
const {onRequest} = require("firebase-functions/v2/https");
const admin = require("firebase-admin");
const credentials = require("./key.json");

// Initialize Firebase Admin SDK
admin.initializeApp({
  credential: admin.credential.cert(credentials),
});
const db = admin.firestore();

/**
 * Checks if the input is a valid email format.
 * @param {string} email - The email to validate.
 * @return {boolean} - Returns true if the email is valid, false otherwise.
 */
function isValidEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

// HTTP endpoint for verifying OTP
const verifyOTP = onRequest({
  region: "asia-south1",
  cors: true,
}, async (req, res) => {
  try {
    let {email, otp} = req.body;

    // Check if both email/uniqueId and otp are provided
    if (!email || !otp) {
      logger.error("Email/UniqueId and OTP are required.");
      return res.status(400).json({
        message: "Email/UniqueId and OTP are required to verify.",
      });
    }

    if (!isValidEmail(email)) {
      logger.info(`Provided input is not an email,`+
        ` assuming it is a unique ID: ${email}`);
      const uniqueIdDoc = await db.collection("uniqueID").doc(email).get();

      if (!uniqueIdDoc.exists) {
        logger.error("No email found for the provided unique ID.");
        return res.status(404).json({
          message: "No email found for the provided unique ID.",
        });
      }

      // Get the email associated with the unique ID
      email = uniqueIdDoc.data().email;
      logger.info(`Email associated with unique ID: ${email}`);
    }

    // Retrieve the OTP for the provided email from Firestore
    const otpDoc = await db.collection("OTP").doc(email).get();

    if (!otpDoc.exists) {
      logger.error("No OTP found for the provided email.");
      return res.status(404).json({
        message: "No OTP found for the provided email."+
        " Please request a new OTP.",
      });
    }

    const {otp: storedOtp, createdAt} = otpDoc.data();

    // Check if the OTP has expired (2 minutes)
    const currentTime = new Date();
    const otpCreationTime = createdAt.toDate();
    const timeDifference = (currentTime - otpCreationTime) / 1000;

    if (timeDifference > 120) {
      logger.error("OTP has expired for this email.");

      await db.collection("OTP").doc(email).update({isExpired: true});

      return res.status(403).json({
        message: "OTP has expired. Please request a new OTP.",
      });
    }

    // Compare the provided OTP with the stored OTP
    if (storedOtp === otp) {
      // OTP is valid
      logger.info(`OTP verification successful for email: ${email}`);
      return res.status(200).json({
        message: "OTP verification successful.",
      });
    } else {
      // OTP does not match
      logger.error(`Invalid OTP for email: ${email}`);
      return res.status(401).json({
        message: "Invalid OTP. Please try again.",
      });
    }
  } catch (error) {
    logger.error("Error verifying OTP:", error.message);
    res.status(500).json({
      message: "An error occurred while verifying the OTP. Please try again.",
    });
  }
});



// Export the verifyOTP function
exports.verifyOTP = verifyOTP;


