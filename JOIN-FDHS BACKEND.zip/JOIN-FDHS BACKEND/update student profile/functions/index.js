const {logger} = require("firebase-functions");
const {onRequest} = require("firebase-functions/v2/https");
const {initializeApp} = require("firebase-admin/app");
// const {getFirestore} = require("firebase-admin/firestore");
const admin = require("firebase-admin");
const nodemailer = require("nodemailer");

initializeApp();
const db = admin.firestore();

/**
 * Verifies an authentication token.
 *
 * @param {string} idToken - The ID token to verify.
 * @return {Promise<object>} - Decoded token information.
 * @throws {Error} - If verification fails or the token is expired.
 */
async function verifyToken(idToken) {
  try {
    const decodedToken = await admin.auth().verifyIdToken(idToken);
    return decodedToken;
  } catch (error) {
    if (error.code === "auth/argument-error" ||
      error.code === "auth/id-token-revoked") {
      throw new Error("Invalid ID token");
    } else if (error.code === "auth/id-token-expired") {
      throw new Error("Expired ID token");
    } else {
      throw new Error("Token verification failed");
    }
  }
}
/**
 * Validates an email address.
 * @param {string} email The email address to validate.
 * @return {boolean} `true` if the email is valid, otherwise `false`.
 */
function isValidEmail(email) {
  const re = /\S+@\S+\.\S+/;
  return re.test(email);
}

/**
 * Validates a phone number.
 * @param {string} phoneNumber The phone number to validate.
 * @return {boolean} `true` if the phone number is valid, otherwise `false`.
 */
function isValidPhoneNumber(phoneNumber) {
  const re = /^\d{10}$/;
  return re.test(phoneNumber);
}

const transporter = nodemailer.createTransport({
  host: "smtp.zoho.com",
  port: 465,
  secure: true,
  auth: {
    user: "admin@fdhs.in",
    pass: "k43m Vvvq mzzy",
  },
});

const allowedOrigins = [
  "http://localhost:3000",
  "true",
];

// API endpoint to retrieve user information
exports.UpdateStudentProfile = onRequest({
  region: "asia-south1",
  cors: allowedOrigins,
}, async (req, res) => {
  try {
    // Extract the ID token from the request headers
    const idToken = req.headers.authorization;
    if (!idToken) {
      return res.status(400).send({message: "ID token is missing"});
    }

    // Verify the ID token
    let decodedToken;
    try {
      decodedToken = await verifyToken(idToken);
    } catch (error) {
      if (error.message === "Invalid ID token") {
        return res.status(401).send({message: "Invalid ID token"});
      } else if (error.message === "Expired ID token") {
        return res.status(401).send({message: "Expired ID token"});
      } else {
        throw error;
      }
    }

    const email = decodedToken.email;

    const {
      fullName,
      RollNumber,
      collegeName,
      stateOfResidence,
      phoneNumber,
    } = req.body;

    // Validate email format
    if (!isValidEmail(email)) {
      return res.status(400).json({error: "Invalid email format"});
    }

    // Validate phone number format
    if (phoneNumber && !isValidPhoneNumber(phoneNumber)) {
      return res.status(402).json({error: "Invalid phone number format"});
    }

    // Only include fields that are defined in the update
    const studentData = {};
    if (fullName) studentData.fullName = fullName;
    if (RollNumber) studentData.RollNumber = RollNumber;
    if (collegeName) {
      studentData.collegeName = collegeName;
    }
    if (stateOfResidence) studentData.stateOfResidence = stateOfResidence;
    if (phoneNumber) studentData.phoneNumber = phoneNumber;

    // Add timestamp
    studentData.lastUpdate = admin.firestore.FieldValue.serverTimestamp();

    if (Object.keys(studentData).length === 0) {
      return res.status(400).json({error: "No data provided for update"});
    }

    const studentRef = db.collection("student").doc(email);

    await studentRef.update(studentData);

    const studentDoc = await studentRef.get();
    const donorData = studentDoc.data();
    const Name = donorData ? donorData.fullName : "User";
    const mailOptions = {
      from: `"JoinFDHS" <admin@fdhs.in>`,
      to: email,
      subject: "Profile Update Confirmation",
      html: `
        <div style="font-family: Arial, sans-serif; line-height: 1.6;
         margin: 20px; padding: 20px; background-color: #f9f9f9;
          border-radius: 8px; border: 1px solid #ddd;">
          <h2 style="color: #4A90E2;">Profile Update Confirmation</h2>
          <p>Dear <strong>${Name}</strong>,</p>
          <p style="font-size: 16px;">Your profile has been
          <strong>successfully updated</strong>.</p>
          <p>If you did not make these changes or believe your
          account has been compromised, please contact us immediately.</p>
          <p>Thank you for keeping your information up to date.</p>
          <p>Sincerely,</p>
          <p><strong>JoinFDHS</strong></p>
        </div>
      `,
    };


    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.error("Error sending email:", error);
      } else {
        console.log("Email sent:", info.response);
      }
    });
    res.status(200).json({message: "Your profile has"+
      " been successfully updated!"});
  } catch (error) {
    logger.error("Error updating student information:", error);
    res.status(500).json({error: "Internal Server Error"});
  }
});
