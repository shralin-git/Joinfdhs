// The Cloud Functions for Firebase SDK to create Cloud Functions and triggers.
const {logger} = require("firebase-functions");
const {onRequest} = require("firebase-functions/v2/https");
const express = require("express");
const app = express();
const nodemailer = require("nodemailer");
const admin = require("firebase-admin");
const credentials = require("./key.json");

// Initialize Firebase Admin SDK
admin.initializeApp({
  credential: admin.credential.cert(credentials),
});
const db = admin.firestore();

app.use(express.json());
app.use(express.urlencoded({extended: true}));

// Create nodemailer transporter with Zoho Mail credentials
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "vinithnaik40@gmail.com",
    pass: "rdut jzcx wkdq jrkv",
  },
});

/**
 * Validates an email address.
 * @param {string} email The email address to validate.
 * @return {boolean} `true` if the email is valid, otherwise `false`.
 */
function validateEmail(email) {
  const re = /\S+@\S+\.\S+/;
  return re.test(email);
}

/**
 * Validates a phone number.
 * @param {string} phoneNumber The phone number to validate.
 * @return {boolean} `true` if the phone number is valid, otherwise `false`.
 */
function validatePhoneNumber(phoneNumber) {
  const re = /^\d{10}$/;
  return re.test(phoneNumber);
}

/**
 * Generates a unique ID by combining the first 4 letters of the full name,
 * a 2-digit random number, and ends with "fdhs".
 * @param {string} fullName The full name of the student.
 * @return {string} The generated unique ID.
 */
function generateUniqueId(fullName) {
  // Extract the first 4 letters from the fullName and convert to uppercase
  const namePart = fullName.substring(0, 3).toUpperCase();

  // Generate a random 2-digit number (from 10 to 99)
  const randomPart = Math.floor(1000 + Math.random() * 9000);

  // Return the ID in the required format
  return `${namePart}${randomPart}@FDHS`;
}

/**
     * Generates a random character from the given set of characters.
     *
     * @return {string} A random character.
     */
function getRandomCharacter() {
  const characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabc"+
  "defghijklmnopqrstuvwxyz0123456789";
  return characters.charAt(Math.floor(Math.random() * characters.length));
}
/**
 * Generates a string that starts with a letter.
 *
 * @return {string} - The generated string.
 */
function generateCustomString() {
  const numbers = Math.floor(Math.random() * 90000) + 10000;
  return `${numbers}`;
}

// HTTP endpoint for adding a new mentor registration
exports.MentorRegistration = onRequest({
  region: "asia-south1", cors: true,
}, async (req, res) => {
  try {
    const userDatas = req.body;
    const {email, phoneNumber, fullName, stateOfResidence,
      mbbsNumber, collegeOrInstitution, specialization} = userDatas;

    // Ensure all required fields are provided
    const requiredFields = ["fullName", "email",
      "mbbsNumber", "collegeOrInstitution",
      "stateOfResidence", "phoneNumber", "specialization"];
    const missingFields = requiredFields.filter((field) => !userDatas[field]);

    if (missingFields.length > 0) {
      return res.status(405).json({message: `Missing required fields:`+
        ` ${missingFields.join(", ")}. Your request failed. Please try again`});
    }

    // Validate email format and phone number length
    if (!validateEmail(email)) {
      return res.status(400).json({
        message: "Invalid email format. Your request failed. Please try again",
      });
    }

    if (!validatePhoneNumber(phoneNumber)) {
      return res.status(400).json({
        message: "Invalid phone number format. Phone number"+
        " must be 10 digits. Your request failed. Please try again",
      });
    }

    const currentDate = new Date();
    // Generate a unique ID for the mentor
    let uniqueId = generateUniqueId(fullName);

    // Check if uniqueId exists in the Firestore collection
    const uniqueIdDoc = await db.collection("uniqueID").doc(uniqueId).get();

    if (uniqueIdDoc.exists) {
      console.log("The uniqueId exists in the database.");
      // Extract the first 4 letters from the fullName and convert to uppercase
      const namePart = fullName.substring(0, 3).toUpperCase();

      const customString = generateCustomString();

      const studentNumber = `${namePart}${customString}@FDHS`;

      const randomChar = getRandomCharacter();

      const updatedUniqueId = studentNumber.slice(0, 3) +
      randomChar + studentNumber.slice(3);

      uniqueId = updatedUniqueId;

      console.log("Changed unique ID "+ updatedUniqueId);
    } else {
      console.log("The uniqueId does not exist in the database.");
    }


    // Check if user already exists in the system
    try {
      const snapshot = await db.collection("registrationApplications")
          .where("email", "==", email)
          .get();

      if (!snapshot.empty) {
        // User already exists, check if they are approved or in progress
        const userData = snapshot.docs[0].data();
        if (userData.status === "approve" || userData.status === "new"||
           userData.status === "hold") {
          return res.status(400).json({
            message: "User already exists in this application",
          });
        }
      }
    } catch (error) {
      console.error("Error checking for existing user:", error);
      return res.status(500).
          json({message: "Error checking for existing user"});
    }

    try {
      const collectionsToCheck = ["student", "admin", "super admin"];
      for (const collection of collectionsToCheck) {
        const userSnapshot = await db.collection(collection).doc(email).get();
        if (userSnapshot.exists) {
          return res.status(404).json({
            message: `User already exists in this application`,
          });
        }
      }
    } catch (error) {
      console.error("Error checking for existing user:", error);
      return res.status(500).json({
        message: "Error checking for existing user",
      });
    }

    // Set default details for mentor
    const userData = {
      fullName,
      email,
      phoneNumber,
      stateOfResidence,
      mbbsNumber,
      collegeOrInstitution,
      specialization,
      status: "new",
      processedBy: "",
      processedDate: "",
      submitDate: currentDate,
      uniqueId,
      userType: "mentor",
    };

    // Store registration details in Firestore
    await db.collection("registrationApplications").doc(email).set(userData);

    // Store the uniqueId and email in the "uniqueID" collection
    await db.collection("uniqueID").doc(uniqueId).set({email});

    // Log success
    logger.info("Mentor registration application submitted successfully");

    // Send success response
    res.status(201).json({
      message: "Your application was successfully submitted! "+
      " Check your email for next step.",
    });

    const recipientName = fullName || "User";

    const mailOptions = {
      from: `"Joinfdhs" <vinithnaik40@gmail.com>`,
      to: email,
      subject: "Application Submitted",
      html: `
        <div style="font-family: Arial, sans-serif; padding: 20px;">
          <div style="max-width: 600px; margin: 0 auto; padding:
           20px; border-radius: 8px;">
            <h2 style="text-align: center; color: #1e90ff;
            font-size: 28px;">
              Application Submitted Successfully
            </h2>
            <p style="font-size: 18px; color: #000000;">
              Dear <strong>${recipientName}</strong>,
            </p>
            <p style="font-size: 16px; color: #333; line-height: 1.6;">
              Thank you for submitting your registration application
              with us. Our team will review your application, and you
              will be notified once it has been approved.
            </p>
            <p style="font-size: 16px; color: #333;">Best regards,</p>
            <p style="font-size: 18px; font-weight: bold; color:
            #1e90ff;">Joinfdhs</p>
          </div>
        </div>
      `,
    };


    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.error("Error sending email:", error);
      } else {
        console.log("Email sent:", info.response);
      }
    });
  } catch (error) {
    // Log error
    logger.error(`Error submitting registration application: ${error}`);

    // Handle errors
    res.status(500).json({message: "Internal Server Error"});
  }
});
