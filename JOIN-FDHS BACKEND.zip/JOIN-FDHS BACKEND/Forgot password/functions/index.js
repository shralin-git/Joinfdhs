const {logger} = require("firebase-functions");
const {onRequest} = require("firebase-functions/v2/https");
const admin = require("firebase-admin");
const axios = require("axios");
const {getFirestore} = require("firebase-admin/firestore");

admin.initializeApp();

const allowedOrigins = [
  "http://localhost:3000",
  "true",
];

/**
 * Check if a string is a valid email format.
 * @param {string} email - The string to check.
 * @return {boolean} - True if the string is a valid email, otherwise false.
 */
function isEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Retrieve the email associated with a unique ID from the uniqueId table.
 * @param {string} uniqueId - The unique ID provided by the user.
 * @return {Promise<string | null>} - The associated email or null if not found.
 */
async function getEmailFromUniqueId(uniqueId) {
  try {
    const uniqueIdDoc = await getFirestore().
        collection("uniqueID").doc(uniqueId).get();
    if (uniqueIdDoc.exists) {
      const {email} = uniqueIdDoc.data();
      return email;
    }
    return null;
  } catch (error) {
    logger.error(`Error retrieving email from uniqueId: ${error.message}`);
    throw new Error("Failed to retrieve email from uniqueId");
  }
}

// Define Cloud Function to handle HTTP requests
exports.ForgotPassword = onRequest(
    {
      region: "asia-south1",
      cors: allowedOrigins,
    },
    async (req, res) => {
      try {
        let {username} = req.body;

        // Check if username is provided
        if (!username) {
          return res.status(400).json({message: "Username is"+
            " required. Please try again."});
        }

        // Check if the username is an email or not
        if (!isEmail(username)) {
          logger.info(`Username is not an email. Checking`+
            ` uniqueId table for the corresponding email.`);
          const emailFromUniqueId = await getEmailFromUniqueId(username);
          if (!emailFromUniqueId) {
            logger.error("User not found in uniqueId table.");
            return res.status(404).json({
              message: "User not found. Please register first.",
            });
          }
          username = emailFromUniqueId;
          logger.info(`Email retrieved from uniqueId: ${username}`);
        }


        const collections = ["student", "mentor", "admin", "super admin"];
        let userFound = false;

        for (const collection of collections) {
          const userDoc = await admin.firestore().
              collection(collection).doc(username).get();
          if (userDoc.exists) {
            userFound = true;
            break; // Exit loop if user is found in any collection
          }
        }

        if (!userFound) {
          return res.status(404).json({message: "No user found with"+
            " this email ID in any of the user tables. Please try again."});
        }

        // Step 2: Proceed to send the password reset email
        const API_KEY = "AIzaSyD7rTiijhl5e77p1beZ_17yKnrUJ13tfiE";

        await axios.post(`https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key=${API_KEY}`, {
          requestType: "PASSWORD_RESET",
          email: username,
        });

        // If password reset email is sent successfully, send response
        res.status(200).
            json({message: "Password reset email sent successfully."});
      } catch (error) {
        console.error("Error sending password reset email:", error);

        // Log the error
        logger.error("Error sending password reset email:", error);

        if (error.code === "auth/user-not-found") {
          return res.status(404).json({message: "No user found with"+
          " this username. Please try again."});
        }

        res.status(500).
            json({message: "Internal server error", error: error.message});
      }
    },
);
