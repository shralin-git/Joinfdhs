const {logger} = require("firebase-functions");
const {onRequest} = require("firebase-functions/v2/https");
const {initializeApp} = require("firebase-admin/app");
const {getFirestore} = require("firebase-admin/firestore");
const admin = require("firebase-admin");
initializeApp();

/**
 * Verifies an authentication token.
 *
 * @param {string} idToken - The ID token to verify.
 * @return {Promise<object>} - Decoded token information.
 * @throws {Error} - If verification fails or the token is expired.
 */
async function verifyToken(idToken) {
  try {
    const decodedToken = await admin.auth().verifyIdToken(idToken);
    return decodedToken;
  } catch (error) {
    if (error.code === "auth/argument-error" ||
      error.code === "auth/id-token-revoked") {
      throw new Error("Invalid ID token");
    } else if (error.code === "auth/id-token-expired") {
      throw new Error("Expired ID token");
    } else {
      throw new Error("Token verification failed");
    }
  }
}
/**
 * Checks if the input is a valid email format.
 * @param {string} input - The input to validate.
 * @return {boolean} - Returns true if the input is a valid email.
 */
function isValidEmail(input) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(input);
}

/**
 * Retrieves user information from Firestore.
 *
 * @param {string} email - The email to retrieve information for.
 * @return {Promise<object|null>} - User data if found, or `null` if not.
 * @throws {Error} - If an error occurs during the process.
 */
async function getUserInfo(email) {
  const firestore = getFirestore();
  const tablesToCheck = ["mentor", "student", "super admin", "admin"];

  for (const table of tablesToCheck) {
    const userDoc = await firestore.collection(table).doc(email).get();
    if (userDoc.exists) {
      return {...userDoc.data(), userType: table};
    }
  }

  return null;
}

/**
 * Checks if a user is an admin, student, mentor, or super admin.
 *
 * @param {string} email - The email address of the user.
 * @return {Promise<string|null>} - The role of the user if found, or null.
 * @throws {Error} - If an error occurs during the process.
 */
async function getUserRole(email) {
  const firestore = getFirestore();
  const adminDoc = await firestore.collection("admin").doc(email).get();
  if (adminDoc.exists) {
    return "admin";
  }

  const studentDoc = await firestore.collection("student").doc(email).get();
  if (studentDoc.exists) {
    return "student";
  }

  const mentorDoc = await firestore.collection("mentor").doc(email).get();
  if (mentorDoc.exists) {
    return "mentor";
  }

  const superAdminDoc = await firestore.
      collection("super admin").doc(email).get();
  if (superAdminDoc.exists) {
    return "super admin";
  }

  return null;
}

/**
 * Retrieves the email associated with a unique ID from Firestore.
 *
 * @param {string} uniqueId - The unique ID to search for.
 * @return {Promise<string|null>} - The associated email if found, or null.
 */
async function getEmailByUniqueId(uniqueId) {
  const firestore = getFirestore();
  const uniqueIdDoc = await firestore.
      collection("uniqueID").doc(uniqueId).get();
  if (uniqueIdDoc.exists) {
    return uniqueIdDoc.data().email;
  }
  return null;
}

const allowedOrigins = [
  "http://localhost:3000",
  "true",
];

exports.getUserProfile = onRequest({
  region: "asia-south1", cors: allowedOrigins,
}, async (req, res) => {
  try {
    // Extract the ID token from the request headers
    const idToken = req.headers.authorization;
    if (!idToken) {
      return res.status(400).send({message: "ID token is missing"});
    }

    // Verify the ID token
    let decodedToken;
    try {
      decodedToken = await verifyToken(idToken);
    } catch (error) {
      if (error.message === "Invalid ID token") {
        return res.status(401).send({message: "Invalid ID token"});
      } else if (error.message === "Expired ID token") {
        return res.status(401).send({message: "Expired ID token"});
      } else {
        throw error;
      }
    }

    const userEmail = decodedToken.email;
    const userRole = await getUserRole(userEmail);
    if (!userRole) {
      return res.status(403).
          send({message: "You are not authorized to view user information"});
    }

    let {username} = req.query;

    if (!username) {
      return res.status(404).
          json({message: "Please provide username."});
    }

    // Check if the username is a valid email, otherwise treat it as a unique ID
    if (!isValidEmail(username)) {
      logger.info(`Provided input is not an email,`+
        ` assuming it's a unique ID: ${username}`);
      const emailFromUniqueId = await getEmailByUniqueId(username);
      if (!emailFromUniqueId) {
        return res.status(404).
            json({message: "No email found for the provided unique ID."});
      }
      username = emailFromUniqueId;
    }

    const userInfo = await getUserInfo(username);

    if (userInfo) {
      res.status(200).json(userInfo);
    } else {
      res.status(404).json({message: "User not found."});
    }
  } catch (error) {
    logger.error("Error retrieving user information:", error);
    res.status(500).json({message: "Internal server error."});
  }
});
