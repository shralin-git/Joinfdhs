const {logger} = require("firebase-functions");
const {onRequest} = require("firebase-functions/v2/https");
const {initializeApp} = require("firebase-admin/app");
const admin = require("firebase-admin");
const nodemailer = require("nodemailer");

initializeApp();

const db = admin.firestore();

/**
 * Validates an email address.
 * @param {string} email The email address to validate.
 * @return {boolean} `true` if the email is valid, otherwise `false`.
 */
function isValidEmail(email) {
  const re = /\S+@\S+\.\S+/;
  return re.test(email);
}

/**
 * Validates a phone number.
 * @param {string} phoneNumber The phone number to validate.
 * @return {boolean} `true` if the phone number is valid, otherwise `false`.
 */
function isValidPhoneNumber(phoneNumber) {
  const re = /^\d{10}$/;
  return re.test(phoneNumber);
}

const transporter = nodemailer.createTransport({
  host: "smtp.zoho.com",
  port: 465,
  secure: true,
  auth: {
    user: "admin@fdhs.in",
    pass: "k43m Vvvq mzzy",
  },
});

const allowedOrigins = [
  "http://localhost:3000",
  "true",
];

// API endpoint to retrieve user information
exports.ContactUs = onRequest({
  region: "asia-south1",
  cors: allowedOrigins,
}, async (req, res) => {
  try {
    const {
      firstName,
      lastName,
      phoneNumber,
      email,
      query,
    } = req.body;

    // Validate required fields
    if (!firstName) {
      return res.status(400).json({error: "First name is required"});
    }

    if (!email) {
      return res.status(400).json({error: "Email is required"});
    }

    if (!isValidEmail(email)) {
      return res.status(400).json({error: "Invalid email format"});
    }

    if (!phoneNumber) {
      return res.status(400).json({error: "Phone number is required"});
    }

    if (!isValidPhoneNumber(phoneNumber)) {
      return res.status(400).json({error: "Invalid phone number format"});
    }

    if (!query) {
      return res.status(400).json({error: "Query is required"});
    }

    const userMailOptions = {
      from: `"JoinFDHS" <admin@fdhs.in>`,
      to: email,
      subject: "Your query has been submitted",
      html: `
        <div style="font-family: Arial, sans-serif; background-color:
         #f4f4f9; padding: 20px;">
          <!-- Outer Wrapper -->
          <div style="max-width: 600px; margin: 0 auto; background-color:
           #fff; border-radius: 10px; overflow: hidden; box-shadow:
            0 4px 8px rgba(0, 0, 0, 0.1); animation: fadeIn 1.5s ease;">

            <!-- Header Section -->
            <div style="background-color: #5a67d8; padding: 20px;
             text-align: center; color: #ffffff;">
              <h1 style="margin: 0; font-size: 24px; animation:
               slideDown 1s ease;">JoinFDHS</h1>
            </div>

            <!-- Body Section -->
            <div style="padding: 30px; color: #333; line-height: 1.6;">
              <p style="font-size: 16px; animation: fadeInUp 1s ease 0.3s;">
                <strong>Dear ${firstName},</strong>
              </p>

              <p style="font-size: 16px; animation: fadeInUp 1s ease 0.5s;">
                Your query has been successfully submitted.
              </p>

              <p style="font-size: 16px; animation: fadeInUp 1s ease 0.7s;">
                We will reply to your query shortly.
              </p>

              <p style="font-size: 16px; animation: fadeInUp 1s ease 0.9s;">
                In the meantime, if you have any further questions
                 or need assistance, feel free to reach out to us.
              </p>

              <p style="font-size: 16px; animation: fadeInUp 1s ease 1.1s;">
                Thank you for contacting us.
              </p>

              <p style="font-size: 16px; animation: fadeInUp 1s ease 1.3s;">
                Sincerely,
              </p>

              <p style="font-size: 18px; font-weight: bold; color: #5a67d8;
              animation: fadeInUp 1s ease 1.5s;">JoinFDHS</p>
            </div>
          </div>
        </div>

        <!-- CSS Animations -->
        <style>
          @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
          }

          @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
          }

          @keyframes slideDown {
            from { opacity: 0; transform: translateY(-50px); }
            to { opacity: 1; transform: translateY(0); }
          }
        </style>
      `,
    };


    transporter.sendMail(userMailOptions, (error, info) => {
      if (error) {
        console.error("Error sending email:", error);
      } else {
        console.log("Email sent:", info.response);
      }
    });


    // Query the Firestore to get the admin's email
    const adminSnapshot = await db.
        collection("super admin").where("primary", "==", "Yes").get();

    if (adminSnapshot.empty) {
      return res.status(404).
          json({error: "No admin document found"});
    }

    // Get the first document (assuming there's only one such document)
    const adminEmail = adminSnapshot.docs[0].data().email;

    const adminMailOptions = {
      from: `"JoinFDHS" <admin@fdhs.in>`,
      to: adminEmail,
      subject: "New Query",
      html: `
        <div style="font-family: Arial, sans-serif; background-color:
         #f4f4f9; padding: 20px;">
          <!-- Email Container -->
          <div style="max-width: 600px; margin: 0 auto; background-color:
           #fff; border-radius: 10px; box-shadow: 0 4px 10px
           rgba(0, 0, 0, 0.1); animation: fadeIn 1.5s ease;">

            <!-- Header -->
            <div style="background-color: #5a67d8; padding: 20px;
            text-align: center; color: #fff;">
              <h1 style="margin: 0; font-size: 24px; animation:
              slideDown 1s ease;">New User Query</h1>
            </div>

            <!-- Body Section -->
            <div style="padding: 30px; color: #333; line-height: 1.6;">
              <p style="font-size: 16px; animation: fadeInUp 1s ease 0.3s;">
                <strong>Dear Admin,</strong>
              </p>

              <p style="font-size: 16px; animation: fadeInUp 1s ease 0.5s;">
                <strong>User Information:</strong>
              </p>

              <!-- User Information Table -->
              <table style="width: 100%; border-collapse: collapse;
              animation: fadeInUp 1s ease 0.7s;">
                <tr>
                  <td style="padding: 10px; font-size: 16px; background-color:
                   #f4f4f4; border-bottom: 2px solid #ddd;">
                   <strong>Name:</strong></td>
                  <td style="padding: 10px; font-size: 16px; background-color:
                   #f9f9f9; border-bottom: 2px solid #ddd;">
                   ${firstName} ${lastName ? lastName : ""}</td>
                </tr>
                <tr>
                  <td style="padding: 10px; font-size: 16px; background-color:
                   #f4f4f4; border-bottom: 2px solid #ddd;"><strong>
                   Phone Number:</strong></td>
                  <td style="padding: 10px; font-size: 16px; background-color:
                   #f9f9f9; border-bottom: 2px solid #ddd;">${phoneNumber}</td>
                </tr>
                <tr>
                  <td style="padding: 10px; font-size: 16px; background-color
                  : #f4f4f4; border-bottom: 2px solid #ddd;"><strong>Email:
                  </strong></td>
                  <td style="padding: 10px; font-size: 16px; background-color:
                   #f9f9f9; border-bottom: 2px solid #ddd;">${email}</td>
                </tr>
              </table>

              <!-- User's Query -->
              <p style="font-size: 16px; line-height: 1.5; margin-top: 20px;
               animation: fadeInUp 1s ease 0.9s;">
                <strong>User's Query:</strong>
              </p>
              <div style="font-size: 16px; padding: 15px; background-color:
               #eef3fd; border: 1px solid #5a67d8; line-height: 1.6;
               animation: fadeInUp 1s ease 1.1s;">
                ${query}
              </div>

              <!-- Important Note -->
              <p style="font-size: 16px; color: #d9534f; margin-top:
               20px; animation: fadeInUp 1s ease 1.3s;">
                <strong>NOTE:</strong> Please respond to the user promptly.
              </p>

              <p style="font-size: 16px; margin-top: 20px; animation:
               fadeInUp 1s ease 1.5s;">Thank you.</p>
              <p style="font-size: 18px; font-weight: bold; color:
               #5a67d8; animation: fadeInUp 1s ease 1.7s;">JoinFDHS</p>
            </div>
          </div>
        </div>

        <!-- CSS Animations -->
        <style>
          @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
          }

          @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
          }

          @keyframes slideDown {
            from { opacity: 0; transform: translateY(-50px); }
            to { opacity: 1; transform: translateY(0); }
          }
        </style>
      `,
    };


    transporter.sendMail(adminMailOptions, (error, info) => {
      if (error) {
        console.error("Error sending email:", error);
      } else {
        console.log("Email sent:", info.response);
      }
    });


    res.status(200).json({message: "Your query has been"+
      " submitted successfully."});
  } catch (error) {
    logger.error("Error submitting user query:", error);
    res.status(500).json({error: "Internal Server Error"});
  }
});
