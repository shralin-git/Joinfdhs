const {logger} = require("firebase-functions");
const {onRequest} = require("firebase-functions/v2/https");
const {initializeApp} = require("firebase-admin/app");
const {getFirestore} = require("firebase-admin/firestore");
const axios = require("axios");
const crypto = require("crypto");
// const nodemailer = require("nodemailer");

const API_KEY = "AIzaSyD7rTiijhl5e77p1beZ_17yKnrUJ13tfiE";

// Initialize Firebase Admin SDK
initializeApp();

/*
// Create nodemailer transporter with Zoho Mail credentials
const transporter = nodemailer.createTransport({
  host: "smtp.zoho.com",
  port: 465,
  secure: true,
  auth: {
    user: "admin@fdhs.in",
    pass: "k43m Vvvq mzzy",
  },
});
*/

const logInS = onRequest({
  region: "asia-south1",
  cors: true,
}, async (req, res) => {
  try {
    let {username, password} = req.body;
    logger.info(`Username: ${username}`);
    logger.info(`Password: ${password}`);

    if (!username || !password) {
      logger.error("Username and password are required."+
        " Your request failed. Please try again.");
      return res.status(401).json({
        message: "Username and password are required."+
        " Your request failed. Please try again.",
      });
    }

    // Check if the username is an email or not
    if (!isEmail(username)) {
      logger.info(`Username is not an email. Checking`+
        ` uniqueId table for the corresponding email.`);
      const emailFromUniqueId = await getEmailFromUniqueId(username);
      if (!emailFromUniqueId) {
        logger.error("User not found in uniqueId table.");
        return res.status(404).json({
          message: "User not found. Please register first.",
        });
      }
      username = emailFromUniqueId; // Replace username with the found email
      logger.info(`Email retrieved from uniqueId: ${username}`);
    }

    // Retrieve user data from multiple tables
    const userData = await retrieveUserData(username);
    if (!userData) {
      logger.error("User not found. Please register first.");
      return res.status(404).json({
        message: "User not found. Please register first.",
      });
    }

    const {data} = userData;

    // Perform user sign-in
    const signInData = await signInUser(username, password);

    // Generate OTP
    const otp = generateOTP();

    // Send OTP via email
    // await sendOTPEmail(username, otp);

    // Store OTP in Firestore OTP table
    await storeOTPInFirestore(username, otp);


    // const EmailID = data.email;

    // Check if uniqueId exists, otherwise use userType
    const uniqueIdOrusername = data.uniqueId || data.email;
    const displayValue = uniqueIdOrusername;

    // Capitalize the first letter of userType
    const userType = data.userType.
        charAt(0).toUpperCase() + data.userType.slice(1);

    // Prepare response object
    const response = {
      idToken: signInData.idToken,
      refreshToken: signInData.refreshToken,
      idTokenExpiresIn: signInData.idTokenExpiresIn,
      uniqueIdOrusername: displayValue,
      userType: userType,
      fullName: data.fullName,
    };

    // Send response
    res.status(200).json(response);
  } catch (error) {
    logger.error(`Error signing in user: ${error.message}`);
    if (error.message === "INVALID_LOGIN_CREDENTIALS") {
      res.status(401).json({
        message: "Invalid username or password",
      });
    } else {
      res.status(500).json({
        message: "An error occurred while signing in. Please try again.",
      });
    }
  }
});

/**
 * Check if a string is a valid email format.
 * @param {string} email - The string to check.
 * @return {boolean} - True if the string is a valid email, otherwise false.
 */
function isEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Retrieve the email associated with a unique ID from the uniqueId table.
 * @param {string} uniqueId - The unique ID provided by the user.
 * @return {Promise<string | null>} - The associated email or null if not found.
 */
async function getEmailFromUniqueId(uniqueId) {
  try {
    const uniqueIdDoc = await getFirestore().
        collection("uniqueID").doc(uniqueId).get();
    if (uniqueIdDoc.exists) {
      const {email} = uniqueIdDoc.data();
      return email;
    }
    return null;
  } catch (error) {
    logger.error(`Error retrieving email from uniqueId: ${error.message}`);
    throw new Error("Failed to retrieve email from uniqueId");
  }
}

/**
 * Generate a 6-digit OTP.
 * @return {string} - A random 6-digit OTP.
 */
function generateOTP() {
  return crypto.randomInt(100000, 999999).toString();
}


/**
 * Send the generated OTP to the user's email.
 * @param {string} email - The user's email.
 * @param {string} otp - The generated OTP.
 * @return {Promise<void>}
 */
/*
async function sendOTPEmail(email, otp) {
  const mailOptions = {
    from: `"JoinFDHS" <admin@fdhs.in>`,
    to: email,
    subject: "Your OTP for JoinFDHS Verification",
    html: `
      <div style="font-family: Arial, sans-serif; max-width:
       600px; margin: auto; border: 1px solid #e0e0e0;
       border-radius: 8px; overflow: hidden;">
        <div style="background-color: #007BFF; color:
        white; padding: 15px; text-align: center;">
          <h2>Welcome to JoinFDHS!</h2>
        </div>
        <div style="padding: 20px;">
          <p>Dear User,</p>
          <p>Your One-Time Password (OTP) to Login:</p>
          <p style="font-size: 24px; font-weight: bold;
          text-align: center; color: #007BFF;">${otp}</p>
          <p style="color: #555;">If you encounter any issues,
          feel free to contact our support team at <a href="mail
          to:admin@fdhs.in" style="color: #007BFF;">admin@fdhs.
          in</a>.</p>
          <p style="margin-top: 20px;">Best regards,<br>
          JoinFDHS</p>
        </div>
      </div>
    `,
  };


  try {
    await transporter.sendMail(mailOptions);
    logger.info(`OTP email sent to ${email}`);
  } catch (error) {
    logger.error(`Error sending OTP email: ${error.message}`);
    throw new Error("Failed to send OTP email");
  }
}
*/

/**
 * Store the generated OTP in the Firestore OTP collection.
 * @param {string} email - The user's email.
 * @param {string} otp - The generated OTP.
 * @return {Promise<void>}
 */
async function storeOTPInFirestore(email, otp) {
  try {
    await getFirestore().collection("OTP").doc(email).set({
      otp: otp,
      createdAt: new Date(),
      email: email,
      isExpired: false,
      expiryTime: new Date(Date.now() + 2 * 60 * 1000),
    });
    logger.info(`OTP stored in Firestore for ${email}`);
  } catch (error) {
    logger.error(`Error storing OTP in Firestore: ${error.message}`);
    throw new Error("Failed to store OTP");
  }
}


/**
 * Sign in user using Firebase Authentication and retrieve additional user data.
 * @param {string} username - The user's email (username).
 * @param {string} password - The user's password.
 * @return {Promise<object>} - An object containing user data.
 * @throws {Error} - Throws an error if sign-in fails.
 */
async function signInUser(username, password) {
  try {
    const signInResponse = await axios.post(`https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${API_KEY}`, {
      email: username,
      password,
      returnSecureToken: true,
    });
    return signInResponse.data;
  } catch (error) {
    if (error.response && error.response.data && error.response.data.error) {
      const errorCode = error.response.data.error.message;
      if (errorCode === "INVALID_PASSWORD" || errorCode === "EMAIL_NOT_FOUND") {
        throw new Error("INVALID_LOGIN_CREDENTIALS");
      } else {
        throw new Error(error.response.data.error.message);
      }
    } else {
      throw new Error("An error occurred during sign-in");
    }
  }
}

/**
 * Retrieve user data from multiple Firestore collections.
 * @param {string} username - The user's username.
 * @return {Promise<{table: string, data: object} | null>}
 */
async function retrieveUserData(username) {
  const tables = ["mentor", "admin", "super admin"];
  for (const table of tables) {
    const userDoc = await getFirestore().collection(table).doc(username).get();
    if (userDoc.exists) {
      return {table, data: userDoc.data()};
    }
  }
  return null;
}

exports.Login = logInS;
