const {logger} = require("firebase-functions");
const {onRequest} = require("firebase-functions/v2/https");
const {initializeApp} = require("firebase-admin/app");
const admin = require("firebase-admin");
const nodemailer = require("nodemailer");
const axios = require("axios");
initializeApp();

const db = admin.firestore();
/**
 * Verifies an authentication token.
 *
 * @param {string} idToken - The ID token to verify.
 * @return {Promise<object>} - Decoded token information.
 * @throws {Error} - If verification fails.
 */
async function verifyToken(idToken) {
  const decodedToken = await admin.auth().verifyIdToken(idToken);
  return decodedToken;
}
/**
 * Validates an email address.
 * @param {string} email The email address to validate.
 * @return {boolean} `true` if the email is valid, otherwise `false`.
 */
function isValidEmail(email) {
  const re = /\S+@\S+\.\S+/;
  return re.test(email);
}

/**
 * Validates a phone number.
 * @param {string} phoneNumber The phone number to validate.
 * @return {boolean} `true` if the phone number is valid, otherwise `false`.
 */
function isValidPhoneNumber(phoneNumber) {
  const re = /^\d{10}$/;
  return re.test(phoneNumber);
}

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "vinithnaik40@gmail.com",
    pass: "rdut jzcx wkdq jrkv",
  },
});

const allowedOrigins = [
  "http://localhost:3000",
  "https://joinfdhsfe.web.app",
];

/**
 * Updates a user in the admin or super-admin collection.
 *
 * @param {string} email - The email of the user to update.
 * @param {Object} userData - The data to update for the user.
 * @return {Promise<Object>} A promise that resolves.
 */
async function findUserAndUpdate(email, userData) {
  const collections = ["admin", "super admin"];
  for (const collection of collections) {
    const userRef = db.collection(collection).doc(email);
    const userDoc = await userRef.get();
    if (userDoc.exists) {
      await userRef.update(userData);
      return {success: true, collection};
    }
  }
  return {success: false};
}

// API endpoint to retrieve user information
exports.UpdateAdminAndSuperAdminProfile = onRequest({
  region: "asia-south1",
  cors: allowedOrigins,
}, async (req, res) => {
  try {
    // Extract the ID token from the request headers
    const idToken = req.headers.authorization;
    if (!idToken) {
      return res.status(400).send("ID token is missing");
    }

    // Verify the ID token
    let decodedToken;
    try {
      decodedToken = await verifyToken(idToken);
    } catch (error) {
      if (error.code === "auth/id-token-expired") {
        return res.status(401).send("ID token has expired");
      }
      return res.status(402).send("Invalid ID token");
    }

    if (!decodedToken) {
      return res.status(402).send("Invalid ID token");
    }

    const email = decodedToken.email;

    const {
      fullName,
      phoneNumber,
      stateOfResidence,
      collegeName,
      EmployeeID,
      oldPassword,
      newPassword,
      confirmNewPassword,
    } = req.body;

    // Validate email format
    if (!isValidEmail(email)) {
      return res.status(404).json({error: "Invalid email format"});
    }

    // Validate phone number format (only if phoneNumber is present)
    if (phoneNumber && !isValidPhoneNumber(phoneNumber)) {
      return res.status(400).json({error: "Invalid phone number format"});
    }

    // Prepare user data with validation for undefined fields
    const userData = {};
    if (fullName) userData.fullName = fullName;
    if (phoneNumber) userData.phoneNumber = phoneNumber;
    if (stateOfResidence) userData.stateOfResidence = stateOfResidence;
    if (collegeName) {
      userData.collegeName = collegeName;
    }
    if (EmployeeID) userData.EmployeeID = EmployeeID;

    // Check if new passwords match
    if (newPassword !== confirmNewPassword) {
      return res.status(406).json({message: "New password and confirm new"+
        " password is not matching please try again"});
    }

    userData.lastUpdate = admin.firestore.FieldValue.serverTimestamp();

    // Check if the user exists in any of the collections and update
    const result = await findUserAndUpdate(email, userData);
    if (!result.success) {
      return res.status(404).json({error: "User not found in"+
        " admin, or super-admin collections"});
    }

    const userRef = db.collection(result.collection).doc(email);
    const Doc = await userRef.get();
    const Data = Doc.data();
    const Name = Data ? Data.fullName : "User";

    if (newPassword) {
      if (!oldPassword) {
        return res.status(400).json({error: "Old password not found"});
      }

      try {
        // Attempt to sign in with the old password
        const signInResponse = await axios.post(
            "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword",
            {
              email,
              password: oldPassword,
              returnSecureToken: true,
            },
            {
              params: {
                key: "AIzaSyD7rTiijhl5e77p1beZ_17yKnrUJ13tfiE",
              },
            },
        );

        if (signInResponse.data && signInResponse.data.idToken) {
          // Update the password if old password is verified
          await axios.post(
              "https://identitytoolkit.googleapis.com/v1/accounts:update",
              {
                idToken: signInResponse.data.idToken,
                password: newPassword,
                returnSecureToken: false,
              },
              {
                params: {
                  key: "AIzaSyD7rTiijhl5e77p1beZ_17yKnrUJ13tfiE",
                },
              },
          );
        }
      } catch (error) {
        // Handle error for incorrect old password
        if (
          error.response &&
          error.response.data &&
          error.response.data.error &&
          error.response.data.error.message === "INVALID_PASSWORD"
        ) {
          return res.status(400).json({error: "Old password is not correct"});
        }

        // Handle other errors
        console.error("Error updating password:", error);
        return res.status(500).json({error: "Old password is not correct"});
      }
    }

    // Determine if password was updated
    const passwordMessage = newPassword ? `
    <p style="font-size: 16px;">
      Additionally, your <strong>password</strong>
      has been successfully updated.
    </p>
    <p>If you did not make this change or believe your account
     has been compromised, please contact us immediately.</p>
    ` : "";

    // Email options with conditional content
    const mailOptions = {
      from: `"Joinfdhs" <vinithnaik40@gmail.com>`,
      to: email,
      subject: "Profile Update Confirmation",
      html: `
      <div style="font-family: Arial, sans-serif; line-height: 1.6;
       margin: 20px; padding: 20px; background-color: #f9f9f9;
        border-radius: 8px; border: 1px solid #ddd;">
        <h2 style="color: #4A90E2;">Profile Update Confirmation</h2>
        <p>Dear <strong>${Name}</strong>,</p>
        <p style="font-size: 16px;">
          Your <strong>profile</strong> has been successfully updated.
        </p>
        ${passwordMessage} <!-- This will only appear if
         newPassword is present -->
        <p>Thank you for keeping your information up to date.</p>
        <p>Sincerely,</p>
        <p><strong>Mediksha Team</strong></p>
        <footer style="margin-top: 20px; border-top: 1px solid
         #ddd; padding-top: 10px;">
          <p style="font-size: 12px; color: #666;">&copy; ${new Date().
      getFullYear()} Mediksha. All rights reserved.</p>
          <p style="font-size: 12px; color: #666;">You are receiving
          this email because you have an account with us.</p>
        </footer>
      </div>
    `,
    };
    // Send the email
    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.error("Error sending email:", error);
      } else {
        console.log("Email sent:", info.response);
      }
    });
    res.status(200).json({message: "User information updated successfully."});
  } catch (error) {
    logger.error("Error updating user information:", error);
    res.status(500).json({error: "Internal Server Error"});
  }
});
